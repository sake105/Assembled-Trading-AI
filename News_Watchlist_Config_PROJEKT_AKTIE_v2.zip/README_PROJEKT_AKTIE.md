# News & Watchlist Config — PROJEKT_AKTIE
Generated: 2025-09-11 16:47:24Z

## Ablage
Entpacke den **Ordner `config/`** nach:
```
D:\PROJEKT_AKTIE\Projekt_1\Grundsachen\input\
```
Ergebnis:
```
D:\PROJEKT_AKTIE\Projekt_1\Grundsachen\input\config\...
```

> Falls euer Script **input\watchlist.txt** erwartet: Kopiere `config/watchlist.txt`
> zusätzlich nach `input/watchlist.txt` (oder erweitere die Suchpfade).

## Inhalt
- `config/watchlist.txt` – konsolidierte Watchlist (US + Europa + Australien)
- `config/company_aliases.yaml` – Aliase für Ticker
- `config/news_whitelist.yaml` – Source-Tiers
- `config/news_scoring.yaml` – Score-Gewichte/Schwellen
- `config/news_categories.yaml` – Kategorien/Keywords
- `config/news_handles.yaml` – (optional) zusätzliche Feeds/Handles
- `config/regions.yaml` – Handelsfenster (Dokumentation)

## Quick-Check
- Ticker: US=50, EU=11, AU=1, gesamt=62
- Keine Duplikate in der Watchlist.
- Börsensuffixe gesetzt (`*.DE`, `*.L`, `*.CO`, `*.AS`, `*.AX`).

