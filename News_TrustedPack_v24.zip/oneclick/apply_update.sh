#!/usr/bin/env bash
set -euo pipefail
cp -R "$(dirname "$0")/../config" "./"
cp -R "$(dirname "$0")/../tools" "./"
python3 tools/apply_news_pack.py
python3 scripts/run_news.py
python3 scripts/run_screener.py
echo "Done"
