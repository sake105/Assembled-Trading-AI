# Apply Trusted News Pack (Windows)
$ErrorActionPreference = "Stop"
# copy config and tools
Copy-Item -Path (Join-Path $PSScriptRoot "..\config") -Destination (Join-Path (Get-Location) "config") -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\tools") -Destination (Join-Path (Get-Location) "tools") -Recurse -Force
Write-Host "==> Merge trusted sources & overrides"
python tools\apply_news_pack.py
Write-Host "==> Fetch news"
python scripts\run_news.py
Write-Host "==> Rerun screener"
python scripts\run_screener.py
Write-Host "==> Done"
