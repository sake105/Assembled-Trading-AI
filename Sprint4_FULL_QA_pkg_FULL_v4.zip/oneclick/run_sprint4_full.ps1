$ErrorActionPreference="Stop"
if (-not (Test-Path ".\.venv")) { python -m venv .venv }
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt

$force=0
if ($force -eq 1) {
  python scripts\run_backfill.py
} else {
  $wl = Get-Content -Path "config\watchlist.txt"
  $need = 0
  foreach ($t in $wl) {
    if (-not (Test-Path ("data\raw\"+$t))) { $need = 1; break }
  }
  if ($need -eq 1) { python scripts\run_backfill.py }
}

python scripts\pull_news_whitelist.py
python scripts\run_sprint3_validation.py --min_trades 35 --max_dd -0.35
python scripts\qa_sprint4.py

Write-Host "Sprint 4 FULL fertig. Dashboard start:  .\oneclick\run_streamlit.ps1"
