$ErrorActionPreference="Stop"
.\.venv\Scripts\Activate.ps1
streamlit run app\streamlit_app.py --server.headless true --server.port 8501
