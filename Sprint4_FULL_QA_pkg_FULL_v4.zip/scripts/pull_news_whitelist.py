import yaml, feedparser, re, pandas as pd
from bs4 import BeautifulSoup
from pathlib import Path

WL_SOURCES = {
  "cnbc.com":1.15,"reuters.com":1.20,"bloomberg.com":1.15,"wsj.com":1.10,"ft.com":1.10,
  "marketwatch.com":1.05,"investing.com":1.00,"finance.yahoo.com":1.00,"deraktionaer.de":1.05,
  "handelsblatt.com":1.12,"faz.net":1.08,"barrons.com":1.12
}

def load_watchlist(p="config/watchlist.txt"):
    return [l.strip() for l in open(p,encoding="utf-8").read().splitlines() if l.strip()]

def guess_tickers(text, wl):
    import re
    hits=[]
    for t in wl:
        if re.search(r'\b'+re.escape(t)+r'\b', text, re.IGNORECASE):
            hits.append(t)
    return list(set(hits))

def clean_text(x):
    try:
        return BeautifulSoup(x, "lxml").get_text(" ", strip=True)
    except Exception:
        return x

def main():
    src = yaml.safe_load(open("src/news/sources.yaml","r",encoding="utf-8"))
    wl_sites = set(src.get("whitelist",[]))
    feeds = src.get("feeds",[])
    tickers = load_watchlist()
    rows=[]
    for url in feeds:
        feed = feedparser.parse(url)
        for e in feed.entries:
            link = e.get("link","")
            host = re.sub(r"^https?://(www\.)?","",link).split("/")[0]
            if host not in wl_sites: 
                continue
            title = clean_text(e.get("title",""))
            summ  = clean_text(e.get("summary",""))
            text = f"{title} {summ}".strip()
            hit_tk = guess_tickers(text, tickers)
            for tk in hit_tk:
                rows.append((tk, host, title, link, WL_SOURCES.get(host,1.0)))
    out_dir = Path("data/curated"); out_dir.mkdir(parents=True, exist_ok=True)
    if rows:
        df = pd.DataFrame(rows, columns=["ticker","source","title","link","weight"])
        score = df.groupby("ticker")["weight"].sum().clip(lower=0, upper=2.0)
        pd.DataFrame({"ticker":score.index, "news_score":score.values}).to_csv(out_dir/"news_scores.csv", index=False)
        sent = (score/score.max()).fillna(0.0)
        pd.DataFrame({"ticker":sent.index, "sentiment":sent.values}).to_csv(out_dir/"news_sentiment.csv", index=False)
        df.to_csv(out_dir/"news_rows.csv", index=False)
        print("News aktualisiert.")
    else:
        pd.DataFrame(columns=["ticker","news_score"]).to_csv(out_dir/"news_scores.csv", index=False)
        pd.DataFrame(columns=["ticker","sentiment"]).to_csv(out_dir/"news_sentiment.csv", index=False)
        pd.DataFrame(columns=["ticker","source","title","link","weight"]).to_csv(out_dir/"news_rows.csv", index=False)
        print("Keine News gefunden.")

if __name__=="__main__":
    main()
