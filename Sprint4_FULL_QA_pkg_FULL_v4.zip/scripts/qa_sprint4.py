import os, glob, json, yaml, pandas as pd
from pathlib import Path

def load_list(p):
    return [l.strip() for l in open(p,encoding="utf-8").read().splitlines() if l.strip()] if os.path.exists(p) else []

def latest_date_for_ticker(ticker):
    p = Path("data/raw")/ticker
    files = sorted(glob.glob(str(p/"*.parquet")))
    if not files: return None
    try:
        dfs = [pd.read_parquet(f)[["date"]].dropna() for f in files]
        if not dfs: return None
        d = pd.concat(dfs, ignore_index=True)
        d["date"]=pd.to_datetime(d["date"])
        return d["date"].max()
    except Exception:
        return None

def main():
    out_dir = Path("data/qa"); out_dir.mkdir(parents=True, exist_ok=True)
    cfg = yaml.safe_load(open("config/config.yaml","r",encoding="utf-8"))
    max_recency = int(cfg.get("qa",{}).get("max_recency_days",5))
    min_tr = int(cfg.get("qa",{}).get("min_trades_per_ticker",35))
    min_hr = float(cfg.get("qa",{}).get("min_hit_rate",0.55))
    max_dd = float(cfg.get("qa",{}).get("max_drawdown",-0.35))
    require_thr = bool(cfg.get("qa",{}).get("require_thresholds",True))

    wl = load_list("config/watchlist.txt")

    rows_raw=[]
    today = pd.Timestamp.today().normalize()
    for t in wl:
        last = latest_date_for_ticker(t)
        if last is None:
            rows_raw.append((t, False, None, None))
        else:
            delta = (today - pd.Timestamp(last).normalize()).days
            rows_raw.append((t, True, str(pd.Timestamp(last).date()), int(delta)))
    raw_df = pd.DataFrame(rows_raw, columns=["ticker","has_raw","last_date","recency_days"])
    raw_df.to_csv(out_dir/"raw_status.csv", index=False)

    val_path = Path("data/validation/validation_report.csv")
    if val_path.exists():
        val = pd.read_csv(val_path)
    else:
        val = pd.DataFrame(columns=["ticker","CAGR","HitRate","AvgNet","MaxDD","Ntrades"])

    covered = set(val["ticker"].unique()) if not val.empty else set()
    miss = [t for t in wl if t not in covered]

    thr_path = Path("data/curated/thresholds.csv")
    has_thr = thr_path.exists()
    thr_df = pd.read_csv(thr_path) if has_thr else pd.DataFrame(columns=["ticker","entry","exit","tp","sl","CAGR","HitRate","Ntrades"])

    ns_path = Path("data/curated/news_scores.csv")
    se_path = Path("data/curated/news_sentiment.csv")
    news_ok = ns_path.exists() and se_path.exists()
    ns_df = pd.read_csv(ns_path) if ns_path.exists() else pd.DataFrame(columns=["ticker","news_score"])

    if not val.empty:
        val_ok = (
            (val["Ntrades"]>=min_tr) &
            (val["HitRate"]>=min_hr) &
            (val["MaxDD"]>=max_dd)
        )
        pass_rate = float(val_ok.mean())
        w_hr = (val["HitRate"]*val["Ntrades"]).sum() / max(1, val["Ntrades"].sum())
        kpis = {
            "tickers_total": len(wl),
            "tickers_with_raw": int(raw_df["has_raw"].sum()),
            "validation_rows": len(val),
            "coverage_ok_pct": float(len(covered)/max(1,len(wl))),
            "pass_rate_pct": pass_rate,
            "weighted_hit_rate": float(w_hr),
            "avg_cagr": float(val["CAGR"].mean()) if len(val)>0 else 0.0,
            "avg_maxdd": float(val["MaxDD"].mean()) if len(val)>0 else 0.0,
            "thresholds_available": has_thr,
            "thresholds_count": int(len(thr_df)),
            "news_present": news_ok,
            "news_coverage": int(len(set(ns_df["ticker"])))
        }
    else:
        kpis = {
            "tickers_total": len(wl),
            "tickers_with_raw": int(raw_df["has_raw"].sum()),
            "validation_rows": 0,
            "coverage_ok_pct": 0.0,
            "pass_rate_pct": 0.0,
            "weighted_hit_rate": 0.0,
            "avg_cagr": 0.0,
            "avg_maxdd": 0.0,
            "thresholds_available": has_thr,
            "thresholds_count": int(len(thr_df)),
            "news_present": news_ok,
            "news_coverage": int(len(set(ns_df["ticker"])))
        }

    summary = (
        "# Sprint 4 – QA Zusammenfassung

"
        f"- Watchlist-Größe: {kpis['tickers_total']}
"
        f"- Rohdaten vorhanden: {kpis['tickers_with_raw']}
"
        f"- Validierte Ticker: {kpis['validation_rows']} (Coverage {kpis['coverage_ok_pct']:.1%})
"
        f"- Pass-Rate (Regeln): {kpis['pass_rate_pct']:.1%}
"
        f"- Gewichtete HitRate: {kpis['weighted_hit_rate']:.1%}
"
        f"- Ø CAGR: {kpis['avg_cagr']:.2%}, Ø MaxDD: {kpis['avg_maxdd']:.2%}
"
        f"- Thresholds vorhanden: {kpis['thresholds_available']} (Anzahl {kpis['thresholds_count']})
"
        f"- News/Sentiment vorhanden: {kpis['news_present']} (Coverage {kpis['news_coverage']})
"
    )
    (Path("data/qa")/"QA_SUMMARY.md").write_text(summary, encoding="utf-8")
    pd.DataFrame([kpis]).to_csv(Path("data/qa")/"qa_kpis.csv", index=False)

    missing = {
        "missing_raw": [t for t in wl if t not in set(raw_df[raw_df["has_raw"]==True]["ticker"])],
        "missing_validation": miss,
        "missing_thresholds": [t for t in wl if t not in set(thr_df["ticker"])] if require_thr else [],
        "stale_raw": [str(r.ticker) for _,r in raw_df.fillna({"recency_days":9999}).iterrows() if r.recency_days is not None and r.recency_days>max_recency]
    }
    import json
    with open(Path("data/qa")/"qa_missing.json","w",encoding="utf-8") as f:
        json.dump(missing, f, indent=2)

    print("QA abgeschlossen.")

if __name__=="__main__":
    main()
