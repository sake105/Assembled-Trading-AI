# Sprint 4 – FULL + QA
Start:
  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
  .\oneclick\run_sprint4_full.ps1
  .\oneclick\run_streamlit.ps1
