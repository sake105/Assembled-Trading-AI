import streamlit as st, pandas as pd, os
st.set_page_config(page_title="Sprint 4 – Dashboard", layout="wide")
st.title("Trading Dashboard – Sprint 4 (mit QA)")

def load_csv(p):
    return pd.read_csv(p) if os.path.exists(p) else pd.DataFrame()

tab1, tab2, tab3 = st.tabs(["Performance", "News", "QA"])

with tab1:
    val = load_csv("data/validation/validation_report.csv")
    th = load_csv("data/curated/thresholds.csv")
    if val.empty:
        st.warning("validation_report.csv nicht gefunden. Erst Backfill & Validation laufen lassen.")
    else:
        val2 = val.copy()
        val2["CAGR%"]=(val2["CAGR"]*100).round(2)
        val2["HitRate%"]=(val2["HitRate"]*100).round(1)
        val2["AvgNet%"]=(val2["AvgNet"]*100).round(2)
        st.subheader("Heatmap-Tabelle (sortiert)")
        st.dataframe(val2.sort_values(["CAGR","HitRate"], ascending=[False,False]))
        st.subheader("Top 15")
        st.table(val2.sort_values(["CAGR","HitRate"], ascending=[False,False]).head(15)[["ticker","CAGR%","HitRate%","AvgNet%","MaxDD","Ntrades"]])
        if not th.empty:
            st.subheader("Thresholds (empfohlen)")
            st.dataframe(th)

with tab2:
    ns = load_csv("data/curated/news_scores.csv")
    nr = load_csv("data/curated/news_rows.csv")
    if ns.empty:
        st.info("Noch keine News-CSV vorhanden. Bitte 'News Pull' ausführen.")
    else:
        st.subheader("News Score je Ticker")
        st.dataframe(ns.sort_values("news_score", ascending=False))
    if not nr.empty:
        st.subheader("Letzte Whitelist-News")
        st.dataframe(nr.tail(50))

with tab3:
    st.subheader("QA-Ergebnisse")
    if os.path.exists("data/qa/QA_SUMMARY.md"):
        st.markdown(open("data/qa/QA_SUMMARY.md","r",encoding="utf-8").read())
    else:
        st.info("Noch keine QA-Daten. Bitte QA-Lauf starten.")

st.caption("© Sprint 4 – Mentor Build")
