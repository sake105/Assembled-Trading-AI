import pandas as pd, numpy as np, yfinance as yf
CCY_SUFFIX_MAP = {
    ".DE":"EUR",".AS":"EUR",".PA":"EUR",".MI":"EUR",".BR":"EUR",".CO":"DKK",
    ".L":"GBP",".SW":"CHF",".ST":"SEK",".HE":"EUR",".OL":"NOK",".MC":"EUR",
    ".AX":"AUD",".TO":"CAD",".V":"CAD",".HK":"HKD"
}
def infer_currency(ticker: str, currency_hint: str|None=None):
    if currency_hint: return currency_hint
    for suf, ccy in CCY_SUFFIX_MAP.items():
        if ticker.endswith(suf): return ccy
    try:
        info = yf.Ticker(ticker).fast_info
        ccy = info.get("currency")
        if ccy: return ccy
    except Exception:
        pass
    return "USD"
def eur_per_ccy(ccy: str):
    pair = f"EUR{ccy}=X"
    try:
        hist = yf.download(pair, period="5y", interval="1d", auto_adjust=True, progress=False)
        if hist is None or hist.empty: return None
        s = hist["Close"].rename("rate")
        return 1.0/s
    except Exception:
        return None
def load_fx_series(ccy: str):
    import pandas as pd
    if ccy=="EUR":
        return pd.Series(1.0, index=pd.date_range("2000-01-01","2100-01-01",freq="D"))
    ser = eur_per_ccy(ccy)
    if ser is None or ser.empty:
        idx = pd.date_range("2000-01-01","2100-01-01",freq="D")
        return pd.Series(1.0, index=idx)
    return ser
def adjust_ohlc(df: pd.DataFrame):
    df = df.copy()
    if "adj_close" in df.columns and "close" in df.columns:
        factor = (df["adj_close"].astype(float) / df["close"].astype(float)).replace([np.inf,-np.inf], np.nan).fillna(1.0)
        for c in ("open","high","low","close"):
            if c in df.columns:
                df[c] = df[c].astype(float) * factor
    return df
def portfolio_ccy_view(df: pd.DataFrame, ticker: str, currency_hint: str|None=None):
    df = df.copy()
    ccy = infer_currency(ticker, currency_hint)
    fx = load_fx_series(ccy)
    d = pd.to_datetime(df["date"] if "date" in df.columns else df.index).normalize()
    fx_align = fx.reindex(d, method="ffill").fillna(method="bfill")
    for c in ("open","high","low","close"):
        if c in df.columns:
            df[c+"_eur"] = df[c].astype(float) * fx_align.values
    return df, ccy
