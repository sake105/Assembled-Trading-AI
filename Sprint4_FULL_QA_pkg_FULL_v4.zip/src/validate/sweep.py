import numpy as np, pandas as pd
from .trade_engine import simulate_trades
def sweep_thresholds(df, score, ticker, entry_grid=range(65,81,5), exit_grid=range(50,61,5),
                     tp_grid=(0.12,0.15,0.18), sl_grid=(0.06,0.08,0.10),
                     start_capital=10000.0, position_fraction=1.0, fee_per_order_eur=1.0,
                     roundtrip_slippage_bps=15, min_price_eur=7.0, min_median_vol=300000):
    rows=[]
    for e in entry_grid:
        for x in exit_grid:
            if x>=e: continue
            for tp in tp_grid:
                for sl in sl_grid:
                    tr = simulate_trades(df, score, ticker, e, x, tp, sl, start_capital, position_fraction,
                                         fee_per_order_eur, roundtrip_slippage_bps, min_price_eur, min_median_vol)
                    if tr.empty:
                        rows.append((e,x,tp,sl,0.0,0.0,0.0,0.0,0)); continue
                    eq = (1.0+tr['net_ret']).cumprod()
                    years = max(1e-6, len(tr)/252.0)
                    cagr = (eq.iloc[-1])**(1/years)-1.0 if len(eq)>0 else 0.0
                    hr = float((tr['hit']=='TP').mean())
                    avg = tr['net_ret'].mean()
                    dd = float(min(0.0, (eq/eq.cummax()-1.0).min()))
                    rows.append((e,x,tp,sl,cagr,hr,avg,dd,len(tr)))
    return pd.DataFrame(rows, columns=["entry","exit","tp","sl","CAGR","HitRate","AvgNet","MaxDD","Ntrades"])
def pick_best(sw: pd.DataFrame, min_trades=35, max_dd=-0.35):
    if sw is None or sw.empty: return None
    sw2 = sw[(sw["Ntrades"]>=min_trades) & (sw["MaxDD"]>=max_dd)]
    if sw2.empty: sw2 = sw
    return sw2.sort_values(["CAGR","HitRate","AvgNet"], ascending=[False, False, False]).head(1)
