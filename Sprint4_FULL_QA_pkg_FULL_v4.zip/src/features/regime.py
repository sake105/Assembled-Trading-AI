import pandas as pd, numpy as np
def regime_labels(df: pd.DataFrame):
    close = df["close"].astype(float)
    ma200 = close.rolling(200).mean()
    bull = (close > ma200).astype(int)
    bear = (close <= ma200).astype(int)
    date = pd.to_datetime(df["date"] if "date" in df.columns else pd.to_datetime(df.index))
    return pd.DataFrame({"regime_bull": bull, "regime_bear": bear, "date": date})
