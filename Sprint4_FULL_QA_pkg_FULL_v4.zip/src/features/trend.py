import pandas as pd, numpy as np
def trend_features(df: pd.DataFrame):
    out = pd.DataFrame(index=df.index)
    close = df["close"].astype(float)
    out["sma20"]  = close.rolling(20).mean()
    out["sma50"]  = close.rolling(50).mean()
    out["sma200"] = close.rolling(200).mean()
    out["ema21"]  = close.ewm(span=21, adjust=False).mean()
    out["ema55"]  = close.ewm(span=55, adjust=False).mean()
    out["above_50"] = (close > out["sma50"]).astype(int)
    out["above_200"] = (close > out["sma200"]).astype(int)
    out["ma_stack_bull"] = ((close>out["sma50"]) & (out["sma50"]>out["sma200"])).astype(int)
    return out
