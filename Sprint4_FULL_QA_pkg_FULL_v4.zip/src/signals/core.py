import pandas as pd, numpy as np
def rule_score(feat: pd.DataFrame):
    s = pd.Series(50.0, index=feat.index, dtype=float)
    if "above_50" in feat:      s += feat["above_50"]*10
    if "above_200" in feat:     s += feat["above_200"]*10
    if "ma_stack_bull" in feat: s += feat["ma_stack_bull"]*10
    if "squeeze_on" in feat:    s -= feat["squeeze_on"]*5
    if "macd_hist" in feat:     s += (feat["macd_hist"]>0).astype(int)*5
    if "rsi" in feat:           s -= ((feat["rsi"]>80)|(feat["rsi"]<20)).astype(int)*7
    if "rs_vol" in feat:        s -= (feat["rs_vol"]>0.5).astype(int)*5
    if "regime_bull" in feat:   s += feat["regime_bull"]*5
    if "regime_bear" in feat:   s -= feat["regime_bear"]*5
    return s.clip(0,100)
