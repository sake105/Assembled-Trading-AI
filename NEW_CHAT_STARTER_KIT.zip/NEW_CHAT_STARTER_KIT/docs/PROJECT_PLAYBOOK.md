# PROJECT PLAYBOOK – Aktien-Pipeline (Sprints 1–2)
*Stand: 2025-08-24 18:07*

Dieses Playbook + Kit stellt sicher, dass du in einem **neuen Chat** sofort nahtlos weiterarbeiten kannst.
Es enthält **Code, Configs, Befehle, Troubleshooting** und einen **Merge-Skript**.

## TL;DR
1) ZIP entpacken.
2) PowerShell öffnen **im entpackten KIT-Ordner**.
3) `.\APPLY_STARTER_KIT.ps1` ausführen und als Root **D:\PROJEKT_AKTIE\Projekt_1\Grundsachen** angeben.
4) venv aktivieren, UTF‑8 einschalten, Screener starten:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   chcp 65001 > $null
   [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
   $env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"
   $env:PYTHONPATH = "$PWD\Sprint2_Update_v24;$PWD\Sprint1_Update_v24;$PWD\OneClick_Autopilot_Addon_v24;$PWD\OneClick_Autopilot_Addon_v24\tools;$PWD\News_AllIn_TrustedFeeds_v24;$PWD\News_TrustedPack_v24"
   python -X utf8 -u ".\Sprint2_Update_v24\scripts\run_screener.py"
   ```

## Inhalt
- **Sprint2_Update_v24/scripts/**
  - run_screener.py (robust, OHLCV/Date/Dedup-Fixes integriert)
  - run_screener_debug.py (Einzelticker + Telemetrie)
  - migrate_raw_layout.py (flach → Jahres-Parquet; legt _flat_backup an)
  - remigrate_from_backup.py (Re-Migration aus _flat_backup)
  - fix_ohlcv_parquet.py (OHLCV-Normalisierung in place)
  - run_events.py (AlphaVantage-Earnings; key aus .env)
  - run_news.py (einfache RSS-Aggregation)
- **Sprint2_Update_v24/config/**
  - watchlist.txt (UTF-8, ohne BOM)
  - config.yaml (mit ta_extras Defaults)
- **tools/**
  - project_report.py (PROJECT_STATUS.txt erzeugen)
- **docs/**
  - PROJECT_PLAYBOOK.md (diese Doku)
  - 00_bootstrap_checklist.txt (Kurz-Checkliste)
- **Top-Level**
  - REQUIREMENTS_MIN.txt
  - APPLY_STARTER_KIT.ps1 (Merge ins Projekt mit Backup)
  - .env.example

## Bekannte Stolpersteine & Fixes
- Unicode/BOM → UTF‑8 einschalten, watchlist.txt BOM-frei (Kit enthält `utf-8-sig`‑Leser).
- KeyError 'date'/'close' → `fix_ohlcv_parquet.py`/Re‑Migration.
- Duplicate columns/duplicate keys → Dedup & Date‑Coalesce in allen Pipelines integriert.
- System32/relative Pfade → Merge‑Skript schreibt **absolute** Pfade, danach `Set-Location` ins Root.
