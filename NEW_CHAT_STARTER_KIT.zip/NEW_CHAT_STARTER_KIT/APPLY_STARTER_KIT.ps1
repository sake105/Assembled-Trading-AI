Param()
# Dieses Skript MERGT den Inhalt des Starter-Kits in dein Projekt-Root.
# Nutzung:
# 1) PowerShell öffnen IM entpackten Kit-Ordner
# 2) .\APPLY_STARTER_KIT.ps1
# 3) Ziel-Root eingeben (z. B. D:\PROJEKT_AKTIE\Projekt_1\Grundsachen)

function Copy-WithBackup {
  param([string]$src, [string]$dstRoot)
  $rel = Resolve-Path $src -Relative
  $target = Join-Path $dstRoot $rel.TrimStart(".\", "./")
  $td = Split-Path $target
  if (-not (Test-Path $td)) { New-Item -ItemType Directory -Path $td -Force | Out-Null }
  if (Test-Path $target) {
    $bk = "$target.bak_{0}" -f (Get-Date -Format "yyyyMMdd_HHmmss")
    Copy-Item $target $bk -Force -Recurse
  }
  Copy-Item $src $target -Recurse -Force
}

$here = Get-Location
$root = Read-Host "Bitte Projekt-Root eingeben (z. B. D:\PROJEKT_AKTIE\Projekt_1\Grundsachen)"
if (-not (Test-Path $root)) { throw "Root nicht gefunden: $root" }

# Dateien/Ordner aus dem KIT in das Root mergen
$items = @(
  "Sprint2_Update_v24\scripts\run_screener.py",
  "Sprint2_Update_v24\scripts\run_screener_debug.py",
  "Sprint2_Update_v24\scripts\migrate_raw_layout.py",
  "Sprint2_Update_v24\scripts\remigrate_from_backup.py",
  "Sprint2_Update_v24\scripts\fix_ohlcv_parquet.py",
  "Sprint2_Update_v24\scripts\run_events.py",
  "Sprint2_Update_v24\scripts\run_news.py",
  "Sprint2_Update_v24\config\watchlist.txt",
  "Sprint2_Update_v24\config\config.yaml",
  "tools\project_report.py",
  "docs\PROJECT_PLAYBOOK.md",
  "docs\00_bootstrap_checklist.txt",
  "run_all_sprint2.ps1",
  "REQUIREMENTS_MIN.txt",
  ".env.example"
)

foreach ($i in $items) {
  $src = Join-Path $here $i
  if (Test-Path $src) {
    $dst = Join-Path $root $i
    $dstDir = Split-Path $dst
    if (-not (Test-Path $dstDir)) { New-Item -ItemType Directory -Path $dstDir -Force | Out-Null }
    if (Test-Path $dst) {
      $bk = "$dst.bak_{0}" -f (Get-Date -Format "yyyyMMdd_HHmmss")
      Copy-Item $dst $bk -Force -Recurse
    }
    Copy-Item $src $dst -Recurse -Force
    Write-Host "Merged -> $dst"
  } else {
    Write-Host "Skip (not found in kit): $i" -ForegroundColor Yellow
  }
}

Write-Host "`n[OK] Starter-Kit gemerged nach $root" -ForegroundColor Green
