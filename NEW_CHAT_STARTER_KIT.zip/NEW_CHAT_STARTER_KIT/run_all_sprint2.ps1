Param()

# Setze ins Projekt-Root (ANPASSEN, falls nötig)
$root = (Get-Location).Path

# UTF-8 & venv
chcp 65001 > $null
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"
. "$root\.venv\Scripts\Activate.ps1"

# Pythonpath
$env:PYTHONPATH = "$root\Sprint2_Update_v24;$root\Sprint1_Update_v24;$root\OneClick_Autopilot_Addon_v24;$root\OneClick_Autopilot_Addon_v24\tools;$root\News_AllIn_TrustedFeeds_v24;$root\News_TrustedPack_v24"

# Optional: Migration (nur wenn nötig)
# python "$root\Sprint2_Update_v24\scripts\migrate_raw_layout.py"

# Screener
python "$root\Sprint2_Update_v24\scripts\run_screener.py"

# Events (wenn ALPHAVANTAGE_KEY gesetzt)
python "$root\Sprint2_Update_v24\scripts\run_events.py"

# News (RSS)
python "$root\Sprint2_Update_v24\scripts\run_news.py"
