from __future__ import annotations
from pathlib import Path
import pandas as pd


import pandas as pd, numpy as np
from pathlib import Path

def dedup_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df.loc[:, ~pd.Index(df.columns).duplicated()].copy()

def coalesce_date_columns(df: pd.DataFrame) -> pd.Series:
    df = dedup_columns(df)
    cand = [c for c in df.columns if str(c).lower() in ("date","datetime","timestamp")]
    if cand:
        s = None
        for c in cand:
            ser = pd.to_datetime(df[c], errors="coerce")
            s = ser if s is None else s.combine_first(ser)
    else:
        s = pd.to_datetime(df.index, errors="coerce")
    try:
        s = s.dt.tz_localize(None)
    except Exception:
        pass
    return s.dt.normalize()

def ensure_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = ["_".join([str(x) for x in t if str(x)]) for t in df.columns]
    df.columns = [str(c).strip() for c in df.columns]

    sdate = coalesce_date_columns(df)
    df = df.loc[:, [c for c in df.columns if str(c).lower() not in ("date","datetime","timestamp")]]
    df.insert(0, "date", sdate)

    low = {c.lower(): c for c in df.columns}
    def pick(keys):
        for k in keys:
            if k in low: return low[k]
        for c in df.columns:
            if c.lower()=="date": continue
            if pd.api.types.is_numeric_dtype(df[c]): return c
        return None

    col = {}
    col["close"]  = pick(["close","adj_close","adj close","adjusted close","adjclose","price"])
    col["open"]   = pick(["open","o"])
    col["high"]   = pick(["high","h"])
    col["low"]    = pick(["low","l"])
    col["volume"] = pick(["volume","vol"])
    if not col["close"] and "Adj Close" in df.columns: col["close"] = "Adj Close"
    if not col["close"] and "Close" in df.columns:     col["close"] = "Close"
    for k in ("open","high","low"):
        if not col[k]: col[k] = col["close"]
    if not col["volume"]:
        df["volume"] = 0
        col["volume"] = "volume"

    out = pd.DataFrame({
        "date":   pd.to_datetime(df["date"], errors="coerce").dt.tz_localize(None),
        "open":   pd.to_numeric(df[col["open"]], errors="coerce"),
        "high":   pd.to_numeric(df[col["high"]], errors="coerce"),
        "low":    pd.to_numeric(df[col["low"]], errors="coerce"),
        "close":  pd.to_numeric(df[col["close"]], errors="coerce"),
        "volume": pd.to_numeric(df[col["volume"]], errors="coerce").fillna(0)
    })
    return out.dropna(subset=["date","close"]).sort_values("date").reset_index(drop=True)

def write_yearly(df: pd.DataFrame, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    for y, chunk in df.groupby(df["date"].dt.year):
        (out_dir / f"{y}.parquet").unlink(missing_ok=True)
        chunk.to_parquet(out_dir / f"{y}.parquet", index=False)

def main():
    ROOT = Path(__file__).resolve().parents[2]
    RAW  = ROOT / "data" / "raw"
    BKP  = RAW / "_flat_backup"; BKP.mkdir(parents=True, exist_ok=True)

    flats = [p for p in RAW.glob("*.*") if p.suffix.lower() in (".csv",".parquet")]
    if not flats:
        print("[INFO] keine Flat-Dateien gefunden."); return

    for f in flats:
        ticker = f.stem.upper()
        try:
            df = pd.read_parquet(f) if f.suffix.lower()==".parquet" else pd.read_csv(f)
        except Exception as e:
            print(f"[SKIP] {f.name}: {e}"); continue
        fixed = ensure_ohlcv(df)
        if fixed.empty:
            print(f"[WARN] {ticker}: keine brauchbaren Daten in {f.name}"); continue
        write_yearly(fixed, RAW / ticker)
        # Original ins Backup verschieben
        to = BKP / f.name
        try: f.rename(to)
        except Exception:
            to.write_bytes(f.read_bytes()); f.unlink(missing_ok=True)
        print(f"[OK] {ticker}: {len(fixed)} Zeilen -> {RAW/ticker}")

    print("[DONE] Migration abgeschlossen.")

if __name__=="__main__":
    main()
