from __future__ import annotations
from pathlib import Path
import pandas as pd, feedparser, time

DEFAULT_FEEDS = [
    "https://feeds.a.dj.com/rss/RSSMarketsMain.xml",
    "https://www.investing.com/rss/news_25.rss",
    "https://www.reutersagency.com/feed/?best-topics=business-finance&post_type=best",
    "https://finance.yahoo.com/news/rssindex",
]

def load_feeds_file():
    here = Path(__file__).resolve().parents[1]
    custom = here/"config"/"news_feeds.txt"
    if custom.exists():
        txt = custom.read_text(encoding="utf-8", errors="ignore")
        feeds = [l.strip() for l in txt.splitlines() if l.strip()]
        if feeds: return feeds
    return DEFAULT_FEEDS

def main():
    out_dir = Path(__file__).resolve().parents[1]/"output"/"news"
    out_dir.mkdir(parents=True, exist_ok=True)
    feeds = load_feeds_file()
    rows = []
    for url in feeds:
        try:
            d = feedparser.parse(url)
            for e in d.entries[:50]:
                rows.append({
                    "source": d.feed.get("title", ""),
                    "title": e.get("title",""),
                    "link": e.get("link",""),
                    "published": e.get("published",""),
                })
        except Exception:
            pass
    if not rows:
        print("[WARN] keine Quellen"); return
    df = pd.DataFrame(rows)
    ts = time.strftime("%Y%m%d_%H%M%S")
    df.to_csv(out_dir/f"news_{ts}.csv", index=False, encoding="utf-8")
    print(f"[OK] News gespeichert: {out_dir} (Rows={len(df)})")

if __name__=="__main__":
    main()
