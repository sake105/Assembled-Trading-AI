from __future__ import annotations
import os, json, time
from pathlib import Path
import pandas as pd, requests

def load_watchlist():
    here = Path(__file__).resolve().parents[1]
    for p in [here/"config"/"watchlist.txt", here.parents[1]/"config"/"watchlist.txt"]:
        if p.exists():
            try: txt=p.read_text(encoding="utf-8-sig")
            except Exception: txt=p.read_text(errors="ignore")
            wl=[x.strip().upper() for x in txt.splitlines() if x.strip()]
            if wl: return wl
    return ["AAPL","MSFT"]

def alpha_earnings(symbol: str, key: str) -> pd.DataFrame:
    url = "https://www.alphavantage.co/query"
    params = {"function":"EARNINGS","symbol":symbol,"apikey":key}
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    data = r.json()
    items = data.get("quarterlyEarnings") or []
    df = pd.DataFrame(items)
    if not df.empty and "reportedDate" in df:
        df["reportedDate"]=pd.to_datetime(df["reportedDate"], errors="coerce")
    return df

def main():
    key = os.getenv("ALPHAVANTAGE_KEY")
    out_dir = Path(__file__).resolve().parents[1]/"output"/"events"
    out_dir.mkdir(parents=True, exist_ok=True)
    wl = load_watchlist()
    if not key:
        print("[WARN] ALPHAVANTAGE_KEY fehlt – Events werden übersprungen.")
        return
    for t in wl:
        try:
            df = alpha_earnings(t, key)
            if df.empty: 
                print(f"[SKIP] {t} – keine Earnings")
                continue
            df.to_csv(out_dir/f"{t}_earnings.csv", index=False, encoding="utf-8")
            print(f"[OK] Earnings gespeichert: {t} ({len(df)})")
        except Exception as e:
            print(f"[ERR] {t}: {e}")
    print("[DONE] Events")

if __name__=="__main__":
    main()
