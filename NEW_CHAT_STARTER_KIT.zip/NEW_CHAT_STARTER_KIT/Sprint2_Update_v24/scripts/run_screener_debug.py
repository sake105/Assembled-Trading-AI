from __future__ import annotations
import os, time, runpy
from pathlib import Path
import pandas as pd

HERE = Path(__file__).resolve().parents[1]
OUT  = HERE / "output" / "debug"; OUT.mkdir(parents=True, exist_ok=True)


import pandas as pd, numpy as np
from pathlib import Path

def dedup_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df.loc[:, ~pd.Index(df.columns).duplicated()].copy()

def coalesce_date_columns(df: pd.DataFrame) -> pd.Series:
    df = dedup_columns(df)
    cand = [c for c in df.columns if str(c).lower() in ("date","datetime","timestamp")]
    if cand:
        s = None
        for c in cand:
            ser = pd.to_datetime(df[c], errors="coerce")
            s = ser if s is None else s.combine_first(ser)
    else:
        s = pd.to_datetime(df.index, errors="coerce")
    try:
        s = s.dt.tz_localize(None)
    except Exception:
        pass
    return s.dt.normalize()

def ensure_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = ["_".join([str(x) for x in t if str(x)]) for t in df.columns]
    df.columns = [str(c).strip() for c in df.columns]

    sdate = coalesce_date_columns(df)
    df = df.loc[:, [c for c in df.columns if str(c).lower() not in ("date","datetime","timestamp")]]
    df.insert(0, "date", sdate)

    low = {c.lower(): c for c in df.columns}
    def pick(keys):
        for k in keys:
            if k in low: return low[k]
        for c in df.columns:
            if c.lower()=="date": continue
            if pd.api.types.is_numeric_dtype(df[c]): return c
        return None

    col = {}
    col["close"]  = pick(["close","adj_close","adj close","adjusted close","adjclose","price"])
    col["open"]   = pick(["open","o"])
    col["high"]   = pick(["high","h"])
    col["low"]    = pick(["low","l"])
    col["volume"] = pick(["volume","vol"])
    if not col["close"] and "Adj Close" in df.columns: col["close"] = "Adj Close"
    if not col["close"] and "Close" in df.columns:     col["close"] = "Close"
    for k in ("open","high","low"):
        if not col[k]: col[k] = col["close"]
    if not col["volume"]:
        df["volume"] = 0
        col["volume"] = "volume"

    out = pd.DataFrame({
        "date":   pd.to_datetime(df["date"], errors="coerce").dt.tz_localize(None),
        "open":   pd.to_numeric(df[col["open"]], errors="coerce"),
        "high":   pd.to_numeric(df[col["high"]], errors="coerce"),
        "low":    pd.to_numeric(df[col["low"]], errors="coerce"),
        "close":  pd.to_numeric(df[col["close"]], errors="coerce"),
        "volume": pd.to_numeric(df[col["volume"]], errors="coerce").fillna(0)
    })
    return out.dropna(subset=["date","close"]).sort_values("date").reset_index(drop=True)


def tprint(msg): print(time.strftime("[%H:%M:%S]"), msg, flush=True)

def main():
    ns = runpy.run_path(str(HERE / "scripts" / "run_screener.py"), run_name="__debug__")
    load_config   = ns.get("load_config",   lambda: {})
    load_prices   = ns.get("load_prices",   lambda t: pd.DataFrame())
    build_features= ns.get("build_features",lambda df,cfg: df)
    rule_score    = ns.get("rule_score",    lambda x: x)

    cfg = load_config()

    # Watchlist lesen (robust)
    wl=None
    for p in [HERE/"config"/"watchlist.txt", HERE.parents[1]/"config"/"watchlist.txt"]:
        if p.exists():
            try: txt=p.read_text(encoding="utf-8-sig")
            except Exception: txt=p.read_text(errors="ignore")
            wl=[x.strip().upper() for x in txt.splitlines() if x.strip()]
            break
    if not wl: wl=["AAPL"]

    ticker = (os.getenv("TICKER") or wl[0]).upper()
    nrows  = int(os.getenv("NROWS", "0"))

    tprint(f"Ticker: {ticker}  NROWS: {nrows or 'ALL'}")
    t0=time.perf_counter(); df=load_prices(ticker)
    if df is None or len(df)==0:
        tprint(f"[SKIP] {ticker} – keine Daten"); return
    if nrows>0 and len(df)>nrows: df=df.tail(nrows).copy()
    tprint(f"load_prices: {len(df)} rows in {time.perf_counter()-t0:.2f}s")

    tprint("build_features: START"); t1=time.perf_counter()
    feat=build_features(df, cfg)
    tprint(f"build_features: DONE in {time.perf_counter()-t1:.2f}s  shape={getattr(feat,'shape',None)}")
    if isinstance(feat, pd.DataFrame):
        feat = dedup_columns(feat)
        idx = coalesce_date_columns(feat)
        feat = feat.loc[:, [c for c in feat.columns if str(c).lower() not in ('date','datetime','timestamp')]]
        feat.insert(0, "date", idx)
        feat = dedup_columns(feat)

    tprint("rule_score: START"); t2=time.perf_counter()
    try: base = rule_score(feat)
    except Exception as e: tprint(f"[WARN] rule_score Fehler: {e}"); base = feat
    tprint(f"rule_score: DONE in {time.perf_counter()-t2:.2f}s")

    of_feat = OUT/f"{ticker}_features.parquet"; of_score = OUT/f"{ticker}_screener.csv"
    if isinstance(feat, pd.DataFrame): feat.to_parquet(of_feat, index=False)
    if isinstance(base, pd.DataFrame): base.to_csv(of_score, index=False, encoding="utf-8")
    tprint(f"[OK] saved: {of_feat} | {of_score}")
    tprint("[DONE] debug run")

if __name__=="__main__":
    main()
