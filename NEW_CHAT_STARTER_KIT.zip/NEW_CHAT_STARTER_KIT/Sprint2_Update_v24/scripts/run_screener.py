from __future__ import annotations
import os, warnings
from pathlib import Path
import pandas as pd, numpy as np

warnings.filterwarnings("ignore", category=RuntimeWarning)

# dotenv optional
try:
    from dotenv import load_dotenv
    envp = Path(__file__).resolve().parents[2] / ".env"
    if envp.exists(): load_dotenv(envp)
except Exception: pass


import pandas as pd, numpy as np
from pathlib import Path

def dedup_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df.loc[:, ~pd.Index(df.columns).duplicated()].copy()

def coalesce_date_columns(df: pd.DataFrame) -> pd.Series:
    df = dedup_columns(df)
    cand = [c for c in df.columns if str(c).lower() in ("date","datetime","timestamp")]
    if cand:
        s = None
        for c in cand:
            ser = pd.to_datetime(df[c], errors="coerce")
            s = ser if s is None else s.combine_first(ser)
    else:
        s = pd.to_datetime(df.index, errors="coerce")
    try:
        s = s.dt.tz_localize(None)
    except Exception:
        pass
    return s.dt.normalize()

def ensure_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = ["_".join([str(x) for x in t if str(x)]) for t in df.columns]
    df.columns = [str(c).strip() for c in df.columns]

    sdate = coalesce_date_columns(df)
    df = df.loc[:, [c for c in df.columns if str(c).lower() not in ("date","datetime","timestamp")]]
    df.insert(0, "date", sdate)

    low = {c.lower(): c for c in df.columns}
    def pick(keys):
        for k in keys:
            if k in low: return low[k]
        for c in df.columns:
            if c.lower()=="date": continue
            if pd.api.types.is_numeric_dtype(df[c]): return c
        return None

    col = {}
    col["close"]  = pick(["close","adj_close","adj close","adjusted close","adjclose","price"])
    col["open"]   = pick(["open","o"])
    col["high"]   = pick(["high","h"])
    col["low"]    = pick(["low","l"])
    col["volume"] = pick(["volume","vol"])
    if not col["close"] and "Adj Close" in df.columns: col["close"] = "Adj Close"
    if not col["close"] and "Close" in df.columns:     col["close"] = "Close"
    for k in ("open","high","low"):
        if not col[k]: col[k] = col["close"]
    if not col["volume"]:
        df["volume"] = 0
        col["volume"] = "volume"

    out = pd.DataFrame({
        "date":   pd.to_datetime(df["date"], errors="coerce").dt.tz_localize(None),
        "open":   pd.to_numeric(df[col["open"]], errors="coerce"),
        "high":   pd.to_numeric(df[col["high"]], errors="coerce"),
        "low":    pd.to_numeric(df[col["low"]], errors="coerce"),
        "close":  pd.to_numeric(df[col["close"]], errors="coerce"),
        "volume": pd.to_numeric(df[col["volume"]], errors="coerce").fillna(0)
    })
    return out.dropna(subset=["date","close"]).sort_values("date").reset_index(drop=True)


def get_ta(cfg: dict | None) -> dict:
    d = cfg or {}
    ta = d.get("ta_extras") or {}
    if not isinstance(ta, dict): ta = {}
    return {"rsi_period": int(ta.get("rsi_period", 14)),
            "sma_fast":   int(ta.get("sma_fast", 20)),
            "sma_slow":   int(ta.get("sma_slow", 50)),
            "bb_window":  int(ta.get("bb_window", 20)),
            "bb_std":     float(ta.get("bb_std", 2.0))}

def load_config() -> dict:
    try:
        import yaml
    except Exception:
        return {}
    roots = [Path(__file__).resolve().parents[1]/"config"/"config.yaml",
             Path(__file__).resolve().parents[2]/"config"/"config.yaml"]
    for p in roots:
        if p.exists():
            try: return yaml.safe_load(p.read_text(encoding="utf-8"))
            except Exception: pass
    return {}

def load_watchlist() -> list[str]:
    paths = [Path(__file__).resolve().parents[1]/"config"/"watchlist.txt",
             Path(__file__).resolve().parents[2]/"config"/"watchlist.txt"]
    for p in paths:
        if p.exists():
            try: txt = p.read_text(encoding="utf-8-sig")
            except Exception: txt = p.read_text(errors="ignore")
            wl = [x.strip().upper() for x in txt.splitlines() if x.strip()]
            if wl: return wl
    return ["AAPL","MSFT","GOOGL","NVDA"]

def load_prices(ticker: str) -> pd.DataFrame:
    ROOT = Path(__file__).resolve().parents[2]
    raw = ROOT / "data" / "raw" / ticker.upper()
    if raw.exists():
        parts = sorted(raw.glob("*.parquet"))
        if parts:
            df = pd.concat([pd.read_parquet(p) for p in parts], ignore_index=True)
            return ensure_ohlcv(df)
    # flat fallback
    for f in [ROOT/"data"/"raw"/f"{ticker.upper()}.csv",
              ROOT/"data"/"raw"/"_flat_backup"/f"{ticker.upper()}.csv"]:
        if f.exists():
            return ensure_ohlcv(pd.read_csv(f))
    # yfinance fallback
    try:
        import yfinance as yf
        start = (pd.Timestamp.today() - pd.DateOffset(years=20)).normalize()
        df = yf.download(ticker, start=start, interval="1d", progress=False, auto_adjust=False)
        if df is not None and len(df):
            return ensure_ohlcv(df.reset_index(drop=False))
    except Exception: pass
    return pd.DataFrame()

def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce").astype(float)
    d = s.diff()
    gain = d.clip(lower=0).ewm(alpha=1/period, adjust=False).mean()
    loss = -d.clip(upper=0).ewm(alpha=1/period, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def build_features(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    ta = get_ta(cfg)
    df = ensure_ohlcv(df)
    c = df["close"]
    feat = pd.DataFrame({"date": df["date"], "close": c})
    feat["ret_1d"] = c.pct_change()
    feat["sma_fast"] = c.rolling(ta["sma_fast"]).mean()
    feat["sma_slow"] = c.rolling(ta["sma_slow"]).mean()
    feat["rsi"] = rsi(c, ta["rsi_period"])
    w, s = ta["bb_window"], ta["bb_std"]
    m = c.rolling(w).mean(); sd = c.rolling(w).std(ddof=0)
    feat["bb_mid"] = m; feat["bb_up"] = m + s*sd; feat["bb_dn"] = m - s*sd
    return dedup_columns(feat)

def rule_score(feat: pd.DataFrame) -> pd.DataFrame:
    f = feat.copy()
    f["trend_up"] = (f["close"] > f["sma_slow"]).astype(int)
    f["mom_pos"]  = (f["sma_fast"] > f["sma_slow"]).astype(int)
    f["rsi_mid"]  = ((f["rsi"] >= 45) & (f["rsi"] <= 65)).astype(int)
    f["score"] = 0.5*f["trend_up"] + 0.3*f["mom_pos"] + 0.2*f["rsi_mid"]
    return f

def main():
    MOD = Path(__file__).resolve().parents[1]
    out_root = MOD / "output"; feats = out_root/"features"; scores = out_root/"scores"
    for p in (out_root, feats, scores): p.mkdir(parents=True, exist_ok=True)

    cfg = load_config(); wl = load_watchlist()
    for t in wl:
        df = load_prices(t)
        if df is None or len(df)==0:
            print(f"[SKIP] {t} - keine Daten"); continue
        feat = build_features(df, cfg)
        # robust date first
        dates = coalesce_date_columns(feat)
        feat = feat.loc[:, [c for c in feat.columns if str(c).lower() not in ("date","datetime","timestamp")]]
        feat.insert(0, "date", dates)
        feat = dedup_columns(feat)
        try: base = rule_score(feat)
        except Exception as e:
            print(f"[WARN] rule_score Fehler: {e}; speichere nur Features"); base = feat
        (scores / f"{t}_screener.csv").write_text("", encoding="utf-8")
        base.to_csv(scores / f"{t}_screener.csv", index=False, encoding="utf-8")
        feat.to_parquet(feats / f"{t}_features.parquet", index=False)
        print(f"[OK] {t} -> {scores / (t + '_screener.csv')}")
    print("[DONE] Screener")

if __name__=="__main__":
    main()
