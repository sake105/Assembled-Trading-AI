from pathlib import Path
import os, sys, json
ROOT = Path.cwd()
out = ROOT / "PROJECT_STATUS.txt"

def ver(mod):
    try:
        m = __import__(mod); return getattr(m,"__version__","unknown")
    except Exception: return "not installed"

info = {
    "root": str(ROOT),
    "python": sys.version.split()[0],
    "packages": {k: ver(k) for k in ["pandas","numpy","pyarrow","yfinance","dotenv","feedparser"]},
    "env": {k: ("SET" if os.getenv(k) else "MISSING") for k in ["ALPHAVANTAGE_KEY","FINNHUB_KEY"]},
}

# Watchlist
wl=None; ticks=[]
for p in [ROOT/"Sprint2_Update_v24"/"config"/"watchlist.txt", ROOT/"config"/"watchlist.txt"]:
    if p.exists(): wl=p; break
if wl:
    txt = wl.read_text(encoding="utf-8-sig", errors="ignore")
    ticks=[x.strip().upper() for x in txt.splitlines() if x.strip()]
info["watchlist"]={"path": str(wl) if wl else None, "count": len(ticks), "first10": ticks[:10]}

# RAW summary
raw = ROOT/"data"/"raw"
summary={}
try:
    cands = set((["AAPL","MSFT","GOOGL","NVDA"] + ticks[:6]))
    for t in cands:
        tp = raw/t
        if tp.exists():
            files = sorted(tp.glob("*.parquet"))
            summary[t]={"parquet_files":len(files), "latest": str(files[-1]) if files else None}
except Exception:
    pass
info["raw_summary"]=summary

out.write_text(json.dumps(info, indent=2, ensure_ascii=False), encoding="utf-8")
print("WROTE", out)
