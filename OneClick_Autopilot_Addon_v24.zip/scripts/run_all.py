# Orchestrator: Backfill -> Screener -> (optional) UI
import argparse, os, subprocess, sys, time
from log_setup import setup_logging
setup_logging()
import logging
log = logging.getLogger("runner")

def run(cmd):
    log.info({"run":cmd})
    rc = subprocess.call(cmd, shell=True)
    if rc != 0:
        log.error({"event":"cmd_failed","cmd":cmd,"rc":rc})
        sys.exit(rc)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--no-ui", action="store_true", help="UI nicht starten")
    args = p.parse_args()

    # Backfill (placeholder -> scripts/run_backfill.py)
    run("python scripts/run_backfill.py")
    # Screener
    run("python scripts/run_screener.py")
    # UI
    if not args.no_ui:
        log.info({"event":"start_ui"})
        run("streamlit run src/ui/app.py")

if __name__ == "__main__":
    main()
