# Bootstrap: ensures folders exist, DuckDB warm-up, YAML sanity
import os, sys, json, pathlib
from log_setup import setup_logging
setup_logging()

import logging
log = logging.getLogger("bootstrap")

NEEDED_DIRS = [
  'data/raw','data/curated','data/features','data/models','data/news_cache','data/journal','logs'
]

def ensure_dirs():
    for d in NEEDED_DIRS:
        os.makedirs(d, exist_ok=True)
        log.info({"event":"ensure_dir","dir":d})

def sanity_configs():
    for p in ['config/config.yaml','config/watchlist.txt','config/news/news_whitelist.yaml','config/news/news_blacklist.yaml']:
        if not os.path.exists(p):
            log.error({"event":"missing_config","path":p})
            raise SystemExit(f"Konfiguration fehlt: {p}")
    log.info({"event":"configs_present"})

def main():
    ensure_dirs()
    sanity_configs()
    log.info({"event":"bootstrap_done"})
    print("Bootstrap OK")

if __name__ == "__main__":
    main()
