# Preflight Doctor: checks Python, packages, files, .env, and write permissions
import os, sys, json, pathlib, importlib, textwrap
from log_setup import setup_logging
setup_logging()
import logging
log = logging.getLogger("doctor")

REQUIRED_PKGS = ["pandas","numpy","duckdb","pyarrow","requests","scikit-learn","lightgbm","tqdm","apscheduler","streamlit","beautifulsoup4","lxml","nltk"]

def check_python():
    major, minor = sys.version_info[:2]
    ok = (major, minor) >= (3,9)
    log.info({"event":"python_version","version": f"{major}.{minor}", "ok": ok})
    if not ok:
        raise SystemExit("Python >= 3.9 erforderlich")

def check_packages():
    missing = []
    for p in REQUIRED_PKGS:
        try:
            importlib.import_module(p)
        except Exception:
            missing.append(p)
    if missing:
        raise SystemExit(f"Fehlende Pakete: {', '.join(missing)}")
    log.info({"event":"packages_ok"})

def check_files():
    paths = ["requirements.txt","config/config.yaml","config/news/news_whitelist.yaml","config/news/news_blacklist.yaml"]
    for p in paths:
        if not os.path.exists(p):
            raise SystemExit(f"Datei fehlt: {p}")
    # watchlist optional aber empfohlen
    if not os.path.exists("config/watchlist.txt"):
        log.warning({"event":"watchlist_missing"})
    else:
        with open("config/watchlist.txt","r",encoding="utf-8") as f:
            if not f.read().strip():
                log.warning({"event":"watchlist_empty"})

def check_env():
    # Keys optional; warnen statt stoppen
    av = os.environ.get("ALPHAVANTAGE_KEY")
    fh = os.environ.get("FINNHUB_KEY")
    if not av and not fh:
        log.warning({"event":"no_api_keys","note":"Nur Yahoo-Basis ohne Fallback verfügbar"})
    else:
        log.info({"event":"api_keys_present","alphavantage": bool(av), "finnhub": bool(fh)})

def write_perm():
    try:
        pathlib.Path("logs").mkdir(exist_ok=True)
        with open("logs/_perm_test.txt","w",encoding="utf-8") as f:
            f.write("ok")
        os.remove("logs/_perm_test.txt")
    except Exception as e:
        raise SystemExit(f"Keine Schreibrechte im Projektordner: {e}")
    log.info({"event":"write_perm_ok"})

def main():
    check_python()
    check_packages()
    check_files()
    check_env()
    write_perm()
    print("Preflight OK")

if __name__ == "__main__":
    main()
