# Logging bootstrap
import json, logging.config, os

def setup_logging(path: str = 'config/logging.json'):
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        logging.config.dictConfig(cfg)
    else:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s %(message)s')
