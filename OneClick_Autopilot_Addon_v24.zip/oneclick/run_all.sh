#!/usr/bin/env bash
set -euo pipefail
echo "==> One-Click Autopilot gestartet"

# 1) venv
if [ ! -d ".venv" ]; then
  echo "==> Erstelle venv"
  python3 -m venv .venv || python -m venv .venv
fi
source .venv/bin/activate

# 2) requirements
echo "==> Installiere requirements"
pip install --upgrade pip
pip install -r requirements.txt

# 3) Preflight
echo "==> Preflight-Doctor"
python tools/preflight_doctor.py

# 4) Bootstrap
echo "==> Bootstrap"
python tools/bootstrap.py

# 5) Pipeline
echo "==> Pipeline Runner"
python scripts/run_all.py
