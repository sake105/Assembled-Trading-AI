# One-Click Runner (Windows PowerShell)
param(
    [switch]$NoUI = $false
)
$ErrorActionPreference = "Stop"
$projectRoot = (Get-Location).Path

Write-Host "==> One-Click Autopilot gestartet in $projectRoot" -ForegroundColor Cyan

# 1) Venv
if (-not (Test-Path ".\.venv")) {
  Write-Host "==> Erstelle venv" -ForegroundColor Yellow
  py -3 -m venv .venv 2>$null; if ($LASTEXITCODE -ne 0) { python -m venv .venv }
}
# Activate venv for this session
$venvActivate = ".\.venv\Scripts\Activate.ps1"
if (-not (Test-Path $venvActivate)) { throw "venv nicht gefunden: $venvActivate" }
. $venvActivate

# 2) Pip install
Write-Host "==> Installiere requirements" -ForegroundColor Yellow
pip install --upgrade pip
pip install -r requirements.txt

# 3) Preflight
Write-Host "==> Preflight-Doctor" -ForegroundColor Yellow
python tools/preflight_doctor.py

# 4) Bootstrap
Write-Host "==> Bootstrap" -ForegroundColor Yellow
python tools/bootstrap.py

# 5) Pipeline (backfill -> screener -> ui)
Write-Host "==> Pipeline Runner" -ForegroundColor Yellow
if ($NoUI) {
  python scripts/run_all.py --no-ui
} else {
  python scripts/run_all.py
}
