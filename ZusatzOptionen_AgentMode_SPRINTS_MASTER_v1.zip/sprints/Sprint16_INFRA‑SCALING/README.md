# Sprint 16: INFRA‑SCALING

**Stand:** 2025-08-28 08:01

Ziel: Skalierung & Stabilität.
Aufgaben:
- Parallelisierung (Joblib/Dask), Cache‑Layer; optional DuckDB/Postgres
Artefakte:
- infra_notes.md, perf_benchmarks.csv, config_db.yaml


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
