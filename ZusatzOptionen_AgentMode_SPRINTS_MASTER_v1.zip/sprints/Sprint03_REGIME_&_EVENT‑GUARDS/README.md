# Sprint 3: REGIME & EVENT‑GUARDS

**Stand:** 2025-08-28 08:01

Ziel: Marktregime und Event‑Schutz.
Aufgaben:
- Regime‑Classifier (Bull/Bear/Sideways/High‑Vola)
- Event‑Guard: Earnings/Guidance/FOMC/Gaps → Entry/Size‑Adjust oder Skip
Artefakte:
- regime_state.csv, event_calendar.csv, regime_report.md


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
