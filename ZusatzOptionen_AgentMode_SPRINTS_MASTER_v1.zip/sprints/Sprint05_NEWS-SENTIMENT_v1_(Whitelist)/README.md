# Sprint 5: NEWS/SENTIMENT v1 (Whitelist)

**Stand:** 2025-08-28 08:01

Ziel: News‑Impact als Zusatzsignal (nur Whitelist).
Aufgaben:
- RSS/API‑Pull (CNBC, Reuters, Bloomberg, FAZ, Der Aktionär …)
- Ticker‑Matching, Themen‑Klassifikation, Sentiment‑Score
- News‑Heatmap
Artefakte:
- news_today.jsonl, news_score.csv, news_heatmap.png


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
