# Sprint 9: BACKTEST‑RIG PRO (WF+MC+Reality‑Check)

**Stand:** 2025-08-28 08:01

Ziel: Robustheits‑Beweis.
Aufgaben:
- WF‑purged (Embargo), Monte‑Carlo (≥1000), Param‑Sens ±10–20 %, White’s Reality Check
Artefakte:
- wf_report.md, mc_summary.csv, rc_results.md, param_sensitivity.csv


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
