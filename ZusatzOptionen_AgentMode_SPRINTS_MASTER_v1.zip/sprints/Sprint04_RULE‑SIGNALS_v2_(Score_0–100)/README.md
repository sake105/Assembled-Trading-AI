# Sprint 4: RULE‑SIGNALS v2 (Score 0–100)

**Stand:** 2025-08-28 08:01

Ziel: regelbasierte Signale (Breakout + RS + Vol‑Filter) inkl. Gebühren/Slippage‑Achtung.
Aufgaben:
- Entry/Exit inkl. SL/TP 3%/6% (ATR‑optional), Turnover‑Cap, Min‑Hold
- Spread/Liquidität‑Gates
Artefakte:
- signals.csv, rules_spec.md


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
