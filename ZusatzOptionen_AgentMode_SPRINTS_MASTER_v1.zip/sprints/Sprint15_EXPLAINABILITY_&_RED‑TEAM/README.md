# Sprint 15: EXPLAINABILITY & RED‑TEAM

**Stand:** 2025-08-28 08:01

Ziel: Erklärbarkeit + Gegenprüfung.
Aufgaben:
- SHAP‑Top‑Features pro Ticker/Regime; Red‑Team‑Review (Top‑3 Gegenargumente + Fix‑Patches)
Artefakte:
- explainability.md, shap_top_features.png, redteam.md


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
