# Sprint 7: RISK & PORTFOLIO v1

**Stand:** 2025-08-28 08:01

Ziel: VolTarget (Portfolio), Risk‑Parity/CVaR‑lite, Cluster‑Neutralität.
Aufgaben:
- Size= f(Vol, Spread, Size, Corr); Turnover‑Cap, Min‑Hold
Artefakte:
- portfolio_plan.csv, risk_report.md


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
