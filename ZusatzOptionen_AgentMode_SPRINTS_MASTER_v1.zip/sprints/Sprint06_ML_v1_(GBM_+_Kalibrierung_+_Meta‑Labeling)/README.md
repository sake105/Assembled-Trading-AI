# Sprint 6: ML v1 (GBM + Kalibrierung + Meta‑Labeling)

**Stand:** 2025-08-28 08:01

Ziel: ML‑Ergänzung mit OOS‑Sicherheit.
Aufgaben:
- GBM je Ticker/Horizont (5/10/20d), purged walk‑forward, FDR
- Platt/Isotonic‑Kalibrierung; Meta‑Labeling als Trade‑Filter
Artefakte:
- /models/*, model_report.md, oos_metrics.csv, calibration_plots.png


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
