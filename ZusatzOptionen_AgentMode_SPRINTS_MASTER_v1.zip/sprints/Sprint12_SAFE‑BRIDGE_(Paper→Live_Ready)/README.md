# Sprint 12: SAFE‑BRIDGE (Paper→Live Ready)

**Stand:** 2025-08-28 08:01

Ziel: Sichere Semi‑Automation.
Aufgaben:
- Limits/Kill‑Switch, Audit‑Trail, Paper‑Loop
Artefakte:
- limits.yaml, audit_log.jsonl, orders.csv


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
