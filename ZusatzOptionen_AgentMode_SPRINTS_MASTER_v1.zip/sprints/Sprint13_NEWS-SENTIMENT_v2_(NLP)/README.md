# Sprint 13: NEWS/SENTIMENT v2 (NLP)

**Stand:** 2025-08-28 08:01

Ziel: NLP‑Upgrade + Ereignis‑Impact.
Aufgaben:
- FinBERT‑ähnliche Klassifikation (leicht), Confidence‑Score, False‑Positive‑Guard
- Event‑Impact‑Templates (Guidance cut, M&A, …)
Artefakte:
- news_score_v2.csv, event_impact.md, model_card.md


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
