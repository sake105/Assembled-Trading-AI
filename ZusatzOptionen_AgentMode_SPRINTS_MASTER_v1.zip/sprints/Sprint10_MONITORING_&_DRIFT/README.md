# Sprint 10: MONITORING & DRIFT

**Stand:** 2025-08-28 08:01

Ziel: Frühwarnsysteme + Auto‑Rollback.
Aufgaben:
- Data/Feature/Label‑Drift, KPI‑Wächter, Regime‑Ampel, Go/No‑Go JSON
Artefakte:
- drift_log.csv, qa_summary.md, go_nogo.json


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
