# Sprint 11: UI/DASHBOARD

**Stand:** 2025-08-28 08:01

Ziel: Streamlit‑Dashboard (Dark Theme) + Daily Briefing.
Aufgaben:
- KPI‑Kacheln, Regime‑Ampel, Top‑15 Picks, News‑Heatmap, Orders‑Planner
Artefakte:
- /app/*, dashboard_config.yaml, daily_briefing.pdf


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
