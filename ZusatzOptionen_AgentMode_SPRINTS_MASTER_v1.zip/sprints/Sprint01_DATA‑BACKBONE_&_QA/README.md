# Sprint 1: DATA‑BACKBONE & QA

**Stand:** 2025-08-28 08:01

Ziel: 10–20 Jahre OHLCV + Splits/Dividenden mit sauberer QA.
Aufgaben:
- Historische Pulls (US/EU), Zeitzonen vereinheitlichen
- Lücken/Outlier behandeln, Duplikate entfernen
- Corporate‑Actions justieren (Adj Close, Splits/Dividenden)
- Manifest + Checksummen + QA‑Bericht erzeugen
Artefakte:
- /data/*.csv|parquet, data_manifest.json, qa_data.md


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
