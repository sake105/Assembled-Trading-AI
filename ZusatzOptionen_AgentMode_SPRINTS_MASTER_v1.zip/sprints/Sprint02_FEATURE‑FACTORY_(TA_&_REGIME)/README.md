# Sprint 2: FEATURE‑FACTORY (TA & REGIME)

**Stand:** 2025-08-28 08:01

Ziel: robuste Feature‑Matrizen (TA + Regime).
Aufgaben:
- TA: RSI, MACD, Stoch, ADX, ATR, Bollinger, KAMA, Donchian, Supertrend, PPO, OBV
- Regime‑Proxys: Trendfilter, Vol‑Buckets, Relative‑Strength‑Buckets
- Leakage‑Schutz, Standardisierung/Robust‑Scaling
Artefakte:
- /features/*, features_manifest.json, drift_report.md


**Akzeptanzkriterien (Go/No-Go):**
- OOS-Sharpe ≥ 0.8, MaxDD ≤ 15 %, Netto-PF > 1.25 (nach TR-Gebühren/Slippage)
- Keine Datenlecks; QA-Report vollständig; Drift-Monitor grün
- Orders.csv valide, Limits/Kill‑Switch aktiv (falls relevant)
