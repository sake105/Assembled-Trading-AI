import streamlit as st, os, pandas as pd
st.set_page_config(page_title="Dashboard – Pro+ (Dark)", layout="wide")
st.markdown('<style>div.block-container{padding-top:1rem;}</style>', unsafe_allow_html=True)
st.title("Trading Dashboard – Pro+ (Dark, Sprint23)")
tabs = st.tabs(["Performance","Signals","Top","News","QA","Orders","ML"])
def load(p): return pd.read_csv(p) if os.path.exists(p) else pd.DataFrame()
with tabs[0]:
    v = load("data/validation/validation_report.csv")
    st.dataframe(v.sort_values(["CAGR","HitRate"], ascending=[False,False]) if not v.empty else pd.DataFrame())
with tabs[1]:
    a = load("data/briefs/alerts_today.csv"); st.dataframe(a if not a.empty else pd.DataFrame())
with tabs[2]:
    t = load("data/briefs/TOP50_scores.csv"); st.dataframe(t if not t.empty else pd.DataFrame())
with tabs[3]:
    n = load("data/curated/news_rows.csv"); st.dataframe(n.tail(50) if not n.empty else pd.DataFrame())
with tabs[4]:
    if os.path.exists("data/qa/QA_SUMMARY.md"): st.markdown(open("data/qa/QA_SUMMARY.md","r",encoding="utf-8").read())
    else: st.info("QA noch nicht gelaufen.")
with tabs[5]:
    o = load("data/curated/order_plan.csv"); st.dataframe(o if not o.empty else pd.DataFrame())
with tabs[6]:
    ms = load("data/curated/ml_scores.csv")
    st.subheader("ML Scores (GradientBoosting)")
    st.dataframe(ms.sort_values("proba", ascending=False) if not ms.empty else pd.DataFrame())
st.caption("Pro+ UI (Sprint23)")
