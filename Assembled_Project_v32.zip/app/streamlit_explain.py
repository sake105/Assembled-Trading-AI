import streamlit as st, os, pandas as pd, glob
st.header("ML-Erklärbarkeit (SHAP)")
files = glob.glob("data/explain/*_shap_importance.csv")
if not files:
    st.info("Noch keine SHAP-Ergebnisse. Erst orchestrator/ ml_shap_explain laufen lassen.")
else:
    for fp in files:
        t = os.path.basename(fp).replace("_shap_importance.csv","")
        st.subheader(t)
        st.dataframe(pd.read_csv(fp, index_col=0).rename(columns={0:"mean|SHAP|"}))
