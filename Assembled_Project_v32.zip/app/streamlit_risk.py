import streamlit as st, pandas as pd, os
st.header("Risiko & Tail")
paths = {
    "Portfolio CVaR-lite": "data/curated/portfolio_weights_cvar.csv",
    "Compliance": "data/qa/compliance_rules.csv",
    "QA Issues": "data/qa/data_quality_issues.csv"
}
for name, p in paths.items():
    st.subheader(name)
    if os.path.exists(p): st.dataframe(pd.read_csv(p))
    else: st.info(f"{p} nicht vorhanden.")
