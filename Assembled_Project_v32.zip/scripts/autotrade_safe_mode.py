import os
from src.brokers.traderepublic_stub import to_tr_buylist
from src.brokers.ibkr_stub import place_orders_csv
def main():
    p = to_tr_buylist()
    print("Trade Republic CSV bereit:", p)
    print(place_orders_csv('data/curated/order_plan.csv'))
    print("SAFE MODE: keine Live-Orders werden gesendet.")
if __name__=='__main__': main()
