import pandas as pd, numpy as np, glob
from pathlib import Path
from src.features.trend import trend_features
from src.features.squeeze import squeeze_features
from src.features.volatility import rs_vol, yz_vol
from src.features.regime import regime_labels
from src.features.momentum import rsi, macd, adx
from src.features.atr import atr
from src.features.highs import proximity_52w_high
from src.features.advanced import advanced_feature_block

def read_raw(ticker):
    p = Path("data/raw")/ticker
    files = sorted(glob.glob(str(p/"*.parquet")))
    return pd.DataFrame() if not files else pd.concat([pd.read_parquet(f) for f in files]).sort_values("date").reset_index(drop=True)

def build_features(df, cfg):
    tf = trend_features(df); sq = squeeze_features(df)
    dfv = df.copy(); dfv["rs_vol"]=rs_vol(df); dfv["yz_vol"]=yz_vol(df)
    reg = regime_labels(df)
    close = df["close"].astype(float)
    r = rsi(close, cfg.get("ta_extras",{}).get("rsi_period",14))
    m_line,m_sig,m_hist = macd(close, cfg.get("ta_extras",{}).get("macd_fast",12), cfg.get("ta_extras",{}).get("macd_slow",26), cfg.get("ta_extras",{}).get("macd_signal",9))
    plus_di, minus_di, adx_val = adx(df, cfg.get("ta_extras",{}).get("adx_period",14))
    A = atr(df, cfg.get("ta_extras",{}).get("atr_period",14))
    prox = proximity_52w_high(df, cfg.get("ta_extras",{}).get("lookback_52w",252))
    adv = advanced_feature_block(df)
    extras = pd.DataFrame({"rsi": r, "macd": m_line, "macd_sig": m_sig, "macd_hist": m_hist, "+DI": plus_di, "-DI": minus_di, "ADX": adx_val, "ATR": A, "prox_52w": prox})
    feat = pd.concat([df, tf, sq, dfv[["rs_vol","yz_vol"]], reg, extras, adv], axis=1)
    return feat
