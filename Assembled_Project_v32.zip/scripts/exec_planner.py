import pandas as pd, yaml, os
def main():
    core = yaml.safe_load(open("config/config.yaml","r",encoding="utf-8"))
    alerts_path = "data/briefs/alerts_post_events.csv"
    alerts = pd.read_csv(alerts_path) if os.path.exists(alerts_path) else (
             pd.read_csv("data/briefs/alerts_filtered.csv") if os.path.exists("data/briefs/alerts_filtered.csv") else (
             pd.read_csv("data/briefs/alerts_today.csv") if os.path.exists("data/briefs/alerts_today.csv") else pd.DataFrame()))
    if alerts.empty:
        print("Keine Alerts."); return
    # Merge liquidity/spread proxies
    ls = pd.read_csv("data/curated/liquidity_spread.csv") if os.path.exists("data/curated/liquidity_spread.csv") else pd.DataFrame()
    if not ls.empty:
        alerts = alerts.merge(ls, on="ticker", how="left")
        # Filter: skip illiquid / high-spread ideas
        alerts = alerts[(alerts["spread_proxy"]<=0.06) | alerts["spread_proxy"].isna()]
    # Cluster-neutral Top-N (optional if cluster_map available)
    cm = pd.read_csv("data/curated/cluster_map.csv") if os.path.exists("data/curated/cluster_map.csv") else pd.DataFrame()
    take = []
    if not cm.empty:
        seen=set()
        for _,r in alerts.sort_values("last_score", ascending=False).iterrows():
            sec = cm[cm['ticker']==r['ticker']]['sector'].values
            key = str(sec[0]) if len(sec)>0 else "NA"
            if key in seen: 
                continue
            seen.add(key); take.append(r)
            if len(take)>=int(core["alerts"]["top_n"]): break
        m = pd.DataFrame(take)
    else:
        m = alerts.sort_values("last_score", ascending=False).head(int(core["alerts"]["top_n"]))
    # Allocate
    w = pd.read_csv("data/curated/portfolio_weights.csv") if os.path.exists("data/curated/portfolio_weights.csv") else pd.DataFrame()
    m = m.merge(w, on="ticker", how="left").fillna({"weight":0})
    capital = float(core["portfolio"]["start_capital_eur"])
    fee = float(core["fees"]["trade_republic_per_order_eur"])
    rows=[]
    for _,r in m.iterrows():
        alloc = capital * r.get("weight",0.0)
        est_price = 50.0
        shares = max(0, int((alloc - fee)/max(1.0, est_price)))
        rows.append((r["ticker"], float(r["last_score"]), float(alloc), est_price, int(shares)))
    pd.DataFrame(rows, columns=["ticker","score","alloc_eur","est_entry_price","shares"]).to_csv("data/curated/order_plan.csv", index=False)
    print("Order-Plan (Liquidity/Cluster aware) -> data/curated/order_plan.csv")
if __name__=='__main__': main()
