import pandas as pd, numpy as np, os
def main():
    # simple MA-regime proxy on benchmark (use AAPL as dummy if no index)
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    bench = wl[0] if wl else "AAPL"
    df = pd.read_csv(f"data/raw_history/{bench}.csv")
    df['date']=pd.to_datetime(df['date'])
    df['ma50']=df['close'].rolling(50).mean()
    df['ma200']=df['close'].rolling(200).mean()
    bull = (df['ma50']>df['ma200']).astype(int)
    bear = (df['ma50']<df['ma200']).astype(int)
    out = pd.DataFrame({'date':df['date'], 'bull':bull, 'bear':bear})
    os.makedirs("data/curated", exist_ok=True)
    out.to_csv("data/curated/regime_market.csv", index=False)
    print("Regime gebaut.")
if __name__=='__main__': main()
