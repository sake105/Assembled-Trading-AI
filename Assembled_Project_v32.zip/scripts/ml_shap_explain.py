import os, joblib, yaml, pandas as pd
from pathlib import Path
import shap
from scripts._feat_build import read_raw, build_features

def main():
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    Path("data/explain").mkdir(parents=True, exist_ok=True)
    for t in wl:
        mp = Path(f"data/models/{t}_gb.joblib")
        if not mp.exists(): continue
        pack = joblib.load(mp); model=pack["model"]; cols=pack["columns"]
        df = read_raw(t)
        if df.empty: continue
        feat = build_features(df, {})
        X = feat.select_dtypes(include=['float64','int64']).fillna(0.0)
        for c in list(X.columns):
            if c not in cols: X = X.drop(columns=[c])
        for c in cols:
            if c not in X.columns: X[c]=0.0
        X = X[cols].tail(500)  # limit for speed
        try:
            explainer = shap.TreeExplainer(model)
            sv = explainer.shap_values(X)
            imp = pd.Series(abs(sv).mean(axis=0), index=X.columns).sort_values(ascending=False).head(30)
            imp.to_csv(f"data/explain/{t}_shap_importance.csv")
        except Exception as ex:
            # fallback: permutation importance could be added later
            print(f"[SHAP] {t} skipped: {ex}")
    print("SHAP Importances -> data/explain/*.csv")
if __name__=='__main__': main()
