import pandas as pd, numpy as np, os, yaml
from scripts._feat_build import read_raw

def main():
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    # Build returns matrix
    rets = {}
    for t in wl:
        df = read_raw(t)
        if df.empty: continue
        rets[t] = df['close'].astype(float).pct_change().dropna().tail(252)
    if not rets:
        print("Keine Returns für Port-VolTarget."); return
    R = pd.DataFrame(rets).dropna(how='all').fillna(0.0)
    cov = R.cov()
    target_vol = 0.15  # 15% p.a.
    # naive equal risk contribution approximation via inverse vol
    vol = np.sqrt(np.diag(cov))*np.sqrt(252)
    w = 1.0/np.maximum(vol, 1e-6)
    w = w / w.sum()
    # scale to target vol (approx)
    port_vol = np.sqrt(w.T @ cov.values @ w) * np.sqrt(252)
    scale = float(target_vol / port_vol) if port_vol>0 else 1.0
    w_scaled = w * min(1.5, max(0.5, scale))
    out = pd.DataFrame({"ticker": cov.columns, "weight_volT": w_scaled})
    out.to_csv("data/curated/portfolio_weights_volT.csv", index=False)
    print("Portfolio VolTarget -> data/curated/portfolio_weights_volT.csv")
if __name__=='__main__': main()
