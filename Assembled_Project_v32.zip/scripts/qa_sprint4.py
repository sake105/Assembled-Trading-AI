import os, pandas as pd
def main():
    os.makedirs("data/qa", exist_ok=True)
    pd.DataFrame([], columns=['issue']).to_csv("data/qa/data_quality_issues.csv", index=False)
    pd.DataFrame([], columns=['rule']).to_csv("data/qa/compliance_rules.csv", index=False)
    print("QA Dateien aktualisiert.")
if __name__=='__main__': main()
