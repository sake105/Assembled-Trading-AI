import pandas as pd, numpy as np, yaml, os
from scripts._feat_build import read_raw
def main():
    cfg = yaml.safe_load(open("config/risk.yaml","r",encoding="utf-8"))
    if not cfg["adaptive_stops"]["enable"]:
        print("Adaptive stops disabled"); return
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    rows=[]
    for t in wl:
        df = read_raw(t); 
        if df.empty: continue
        atr = (df['high'].astype(float)-df['low'].astype(float)).rolling(14).mean().iloc[-1]
        tp = cfg["adaptive_stops"]["atr_mult_tp"] * atr / max(1e-6, df['close'].astype(float).iloc[-1])
        sl = cfg["adaptive_stops"]["atr_mult_sl"] * atr / max(1e-6, df['close'].astype(float).iloc[-1])
        rows.append((t, float(tp), float(sl), int(cfg["adaptive_stops"]["max_holding_days"])))
    pd.DataFrame(rows, columns=["ticker","tp_pct","sl_pct","max_days"]).to_csv("data/curated/adaptive_stops.csv", index=False)
    print("Adaptive stops -> data/curated/adaptive_stops.csv")
if __name__=='__main__': main()
