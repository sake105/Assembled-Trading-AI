import pandas as pd, numpy as np, os
from scripts._feat_build import read_raw
from pathlib import Path

def main():
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    rows=[]
    for t in wl:
        df = read_raw(t)
        if df.empty: continue
        # Proxy für Spread: Median( (High-Low)/Close ) über 5 Tage
        hlc = (df['high'].astype(float)-df['low'].astype(float))/df['close'].astype(float)
        sp = hlc.rolling(5).median().iloc[-1]
        # Liquidity proxy: median volume (last 20)
        lv = df['volume'].rolling(20).median().iloc[-1] if 'volume' in df.columns else np.nan
        rows.append((t, float(sp), float(lv) if pd.notna(lv) else np.nan))
    out = pd.DataFrame(rows, columns=["ticker","spread_proxy","median_vol_20"])
    Path("data/curated").mkdir(parents=True, exist_ok=True)
    out.to_csv("data/curated/liquidity_spread.csv", index=False)
    print("Liquidity/Spread proxy -> data/curated/liquidity_spread.csv")
if __name__=='__main__': main()
