import pandas as pd, os
from pathlib import Path
def main():
    # expects CSV at data/raw_events/earnings.csv with columns: ticker,date,event
    p = Path("data/raw_events/earnings.csv")
    if not p.exists():
        print("Keine earnings.csv gefunden (optional)."); return
    df = pd.read_csv(p)
    Path("data/curated").mkdir(parents=True, exist_ok=True)
    df.to_csv("data/curated/corporate_events.csv", index=False)
    print("Earnings geladen -> corporate_events.csv")
if __name__=='__main__': main()
