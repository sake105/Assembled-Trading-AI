import pandas as pd, os, yaml
def main():
    os.makedirs("data/briefs", exist_ok=True)
    core = yaml.safe_load(open("config/config.yaml","r",encoding="utf-8"))
    entry = core["backtest"]["entry"]
    from scripts._feat_build import read_raw, build_features
    from src.signals.core import rule_score
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    rows=[]
    for t in wl:
        df = read_raw(t); feat = build_features(df, core); sc = rule_score(feat)
        rows.append((t, float(sc.tail(1).values[0])))
    pd.DataFrame(rows, columns=['ticker','last_score']).to_csv("data/briefs/alerts_today.csv", index=False)
    print("alerts_today.csv erzeugt.")
if __name__=='__main__': main()
