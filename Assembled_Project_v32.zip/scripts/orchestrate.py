import subprocess, sys
def run(cmd):
    print(">>", cmd); rc = subprocess.call(cmd, shell=True); 
    if rc!=0: print("Fehler:", rc); return rc
    return 0
def main():
    seq = [
        "python scripts/run_backfill.py",
        "python scripts/build_market_regime.py",
        "python scripts/pull_news_whitelist.py",
        "python scripts/news_dedup_rank.py",
        "python scripts/optimize_thresholds.py",
        "python scripts/train_gb_models.py",
        "python scripts/predict_ml_scores.py",
        "python scripts/run_validation_with_thresholds.py",
        "python scripts/generate_daily_briefs.py",
        "python scripts/qa_sprint4.py",
        "python scripts/portfolio_builder.py",
        "python scripts/vol_target.py",
        "python scripts/adaptive_stops.py",
        "python scripts/exec_planner.py",
        "python scripts/meta_labeling.py",
        "python scripts/calibrate_proba.py",
        "python scripts/filter_costs.py",
        "python scripts/apply_event_guard.py",
        "python scripts/macro_vix_proxy.py",
        "python scripts/portfolio_cvar_lite.py",
        "python scripts/autotrade_safe_mode.py"
    ]
    for c in seq:
        rc = run(c)
        if rc!=0: sys.exit(rc)
    print("Orchestrierung fertig (Sprint28 SAFE).")
if __name__=='__main__': main()
