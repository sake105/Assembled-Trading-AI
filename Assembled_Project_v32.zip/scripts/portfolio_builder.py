import pandas as pd, os
def main():
    vp = "data/validation/validation_report.csv"
    if not os.path.exists(vp):
        print("validation_report fehlt."); return
    v = pd.read_csv(vp)
    w = (v['CAGR'].clip(lower=0)*v['HitRate'].clip(lower=0)).fillna(0)
    w = w / (w.sum() if w.sum()>0 else 1.0)
    out = v[['ticker']].copy(); out['weight']=w
    out.to_csv("data/curated/portfolio_weights.csv", index=False)
    print("portfolio_weights.csv erstellt.")
if __name__=='__main__': main()
