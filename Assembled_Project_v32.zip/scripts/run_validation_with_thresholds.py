import yaml, pandas as pd
from scripts._feat_build import read_raw, build_features
from src.signals.core import rule_score
from src.validate.trade_engine import simulate_trades
def main():
    cfg = yaml.safe_load(open("config/config.yaml","r",encoding="utf-8"))
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    rows=[]
    for t in wl:
        df = read_raw(t); feat = build_features(df, cfg)
        sc = rule_score(feat)
        tr = simulate_trades(feat, sc, t, cfg["backtest"]["entry"], cfg["backtest"]["exit"],
                             cfg["backtest"]["tp_pct"], cfg["backtest"]["sl_pct"],
                             cfg["portfolio"]["start_capital_eur"], cfg["portfolio"]["position_fraction"],
                             cfg["fees"]["trade_republic_per_order_eur"], cfg["slippage"]["roundtrip_bps"],
                             cfg["liquidity_filter"]["min_price_eur"], cfg["liquidity_filter"]["min_median_volume"],
                             cfg["portfolio"]["dynamic_sizing"], cfg["portfolio"]["kelly_scale"])
        if tr.empty: continue
        eq=(1+tr['net_ret']).cumprod()
        hit = (tr['hit']=="TP").mean()
        rows.append((t, float(eq.iloc[-1]-1.0), float(hit), float((eq/eq.cummax()-1.0).min())))
    pd.DataFrame(rows, columns=['ticker','CAGR','HitRate','MaxDD']).to_csv("data/validation/validation_report.csv", index=False)
    print("validation_report.csv geschrieben.")
if __name__=='__main__': main()
