import pandas as pd, numpy as np, yaml, os
from scripts._feat_build import read_raw, build_features
from src.signals.core import rule_score
from src.signals.blend import blend_scores
from src.validate.trade_engine import simulate_trades

def run_ped(t, cfg, pre=1, post=10):
    # Simple Post-Earnings Drift: enter on positive gap + strong score, hold 'post' days
    df = read_raw(t)
    if df.empty: return pd.DataFrame()
    feat = build_features(df, cfg)
    score = blend_scores(rule_score(feat), t, cfg).reset_index(drop=True)
    px = df['close'].astype(float).reset_index(drop=True)
    gap = (px - px.shift(1))/px.shift(1)
    events = pd.read_csv("data/curated/corporate_events.csv") if os.path.exists("data/curated/corporate_events.csv") else pd.DataFrame()
    if events.empty: return pd.DataFrame()
    e = events[events['ticker']==t]
    trades=[]
    for d in e['date']:
        # find index of date
        idx = pd.to_datetime(df['date']).dt.date
        where = np.where(idx==pd.to_datetime(d).date())[0]
        if len(where)==0: continue
        i = where[0]
        if i<1 or i>=len(df)-post: continue
        if gap.iloc[i] > 0 and score.iloc[i] >= cfg["backtest"]["entry"]:
            # simulate fixed holding
            p0 = px.iloc[i]; p1 = px.iloc[i+post]
            ret = (p1/p0)-1.0
            trades.append((t, int(i), float(ret), "TP" if ret>=cfg["backtest"]["tp_pct"] else ("SL" if ret<=-cfg["backtest"]["sl_pct"] else "HOLD")))
    return pd.DataFrame(trades, columns=["ticker","idx","ret","hit"])

def main():
    cfg = yaml.safe_load(open("config/config.yaml","r",encoding="utf-8"))
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    out=[]
    for t in wl:
        r = run_ped(t, cfg)
        if not r.empty: out.append(r)
    if out:
        pd.concat(out).to_csv("data/validation/earnings_ped.csv", index=False); print("Earnings-PED gespeichert.")
    else:
        print("Keine PED-Trades.")
if __name__=='__main__': main()
