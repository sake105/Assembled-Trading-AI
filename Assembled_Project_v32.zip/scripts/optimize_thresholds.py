import yaml, json
def main():
    cfg = yaml.safe_load(open("config/config.yaml","r",encoding="utf-8"))
    # simple static (placeholder) to keep offline functional
    open("data/curated/thresholds.json","w",encoding="utf-8").write(json.dumps({"entry":cfg["backtest"]["entry"],"exit":cfg["backtest"]["exit"]}))
    print("thresholds.json geschrieben.")
if __name__=='__main__': main()
