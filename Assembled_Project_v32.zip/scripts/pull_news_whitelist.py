import os, pandas as pd
def main():
    # offline stub: read from local data/raw_news/*.csv if present
    os.makedirs("data/curated", exist_ok=True)
    path = "data/curated/news_scores.csv"
    if not os.path.exists(path):
        pd.DataFrame([], columns=['ticker','news_score']).to_csv(path, index=False)
    print("News-Whitelist (offline stub) ok.")
if __name__=='__main__': main()
