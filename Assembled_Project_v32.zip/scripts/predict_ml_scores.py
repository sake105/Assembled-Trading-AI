import os, yaml, joblib, pandas as pd
from pathlib import Path
from scripts._feat_build import read_raw, build_features
def main():
    cfg = yaml.safe_load(open("config/model.yaml","r",encoding="utf-8"))
    if not cfg.get("ml",{}).get("enable", True): 
        print("ML disabled."); return
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    rows=[]
    for t in wl:
        mp = Path(f"data/models/{t}_gb.joblib")
        if not mp.exists(): continue
        pack = joblib.load(mp); model = pack["model"]; cols = pack["columns"]
        df = read_raw(t)
        if df.empty: continue
        feat = build_features(df, {})
        X = feat.select_dtypes(include=['float64','int64']).fillna(0.0)
        for c in list(X.columns):
            if c not in cols: X = X.drop(columns=[c])
        for c in cols:
            if c not in X.columns: X[c]=0.0
        X = X[cols]
        proba = model.predict_proba(X)[:,1]
        rows.append({"ticker":t, "date": str(pd.to_datetime(feat['date'] if 'date' in feat.columns else feat.index).iloc[-1].date()), "proba": float(proba[-1])})
    out = Path("data/curated"); out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out/"ml_scores.csv", index=False)
    print("ML scores -> data/curated/ml_scores.csv")
if __name__=='__main__': main()
