import pandas as pd, yaml, os
def main():
    cfg = yaml.safe_load(open("config/alpha_hardening.yaml","r",encoding="utf-8"))
    if not cfg["cost_filter"]["enable"]: 
        print("Cost filter disabled"); return
    fee = float(cfg["cost_filter"]["min_ev_pct"])
    sl_bps = float(cfg["cost_filter"]["slippage_bps"])
    alerts = pd.read_csv("data/briefs/alerts_today.csv") if os.path.exists("data/briefs/alerts_today.csv") else pd.DataFrame()
    if alerts.empty: 
        print("Keine Alerts."); return
    # Expectation proxy: use last_score scaled to [0,1] and map to TP/SL from config/backtest (approx).
    # For better results plug in calibrated ML proba.
    import yaml as yml
    core = yml.safe_load(open("config/config.yaml","r",encoding="utf-8"))
    tp = float(core["backtest"]["tp_pct"]); sl = float(core["backtest"]["sl_pct"])
    # Estimate p from score (very rough): p ~ score/100
    alerts["p"] = alerts["last_score"].clip(0,100)/100.0
    # Round-trip slippage in pct:
    alerts["slip"] = sl_bps/10000.0
    alerts["EV"] = alerts["p"]*tp - (1-alerts["p"])*sl - alerts["slip"]
    filt = alerts[alerts["EV"] >= cfg["cost_filter"]["min_ev_pct"]].copy()
    filt.to_csv("data/briefs/alerts_filtered.csv", index=False)
    print("Cost-filtered alerts -> data/briefs/alerts_filtered.csv")
if __name__=='__main__': main()
