import pandas as pd, yaml, os
from datetime import timedelta
def main():
    cfg = yaml.safe_load(open("config/alpha_hardening.yaml","r",encoding="utf-8"))
    if not cfg["events"]["enable"]:
        print("Events guard disabled"); return
    alerts = pd.read_csv("data/briefs/alerts_filtered.csv") if os.path.exists("data/briefs/alerts_filtered.csv") else (
             pd.read_csv("data/briefs/alerts_today.csv") if os.path.exists("data/briefs/alerts_today.csv") else pd.DataFrame())
    if alerts.empty: 
        print("Keine Alerts."); return
    # Expect corporate_events.csv with columns: ticker,date,event (e.g., EARNINGS)
    ce_path = "data/curated/corporate_events.csv"
    if not os.path.exists(ce_path):
        alerts.to_csv("data/briefs/alerts_post_events.csv", index=False); print("Keine Events-Datei, passthrough."); return
    ce = pd.read_csv(ce_path); ce["date"]=pd.to_datetime(ce["date"]).dt.date
    a = alerts.copy()
    a["today"] = pd.Timestamp.today().date()
    pre = int(cfg["events"]["pre_earnings_days"]); post = int(cfg["events"]["post_earnings_days"])
    keep=[]
    for _,r in a.iterrows():
        t=r["ticker"]; ok=True
        cte = ce[ce["ticker"]==t]["date"]
        for d in cte:
            if a["today"].iloc[0] >= d - timedelta(days=pre) and a["today"].iloc[0] <= d + timedelta(days=post):
                ok=False; break
        if ok: keep.append(True)
        else: keep.append(False)
    a = a[pd.Series(keep)]
    a.drop(columns=["today"], inplace=True)
    a.to_csv("data/briefs/alerts_post_events.csv", index=False)
    print("Event-guarded alerts -> data/briefs/alerts_post_events.csv")
if __name__=='__main__': main()
