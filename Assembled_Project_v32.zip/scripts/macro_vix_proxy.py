import pandas as pd, os, yaml
from pathlib import Path
def main():
    cfg = yaml.safe_load(open("config/alpha_hardening.yaml","r",encoding="utf-8"))
    if not cfg["macro"]["enable"]: 
        print("Macro disabled"); return
    # Expect optional CSV at data/raw_macro/vix.csv with columns: date,vix
    p = Path("data/raw_macro/vix.csv")
    if not p.exists():
        print("Keine VIX-Datei (optional)."); return
    df = pd.read_csv(p); df["date"]=pd.to_datetime(df["date"]).dt.tz_localize(None)
    df.to_csv("data/curated/macro_vix.csv", index=False)
    print("VIX proxy curated.")
if __name__=='__main__': main()
