import pandas as pd, os
def main():
    # offline stub: pass-through
    if not os.path.exists("data/curated/news_scores.csv"):
        pd.DataFrame([], columns=['ticker','news_score']).to_csv("data/curated/news_scores.csv", index=False)
    print("News dedup/rank ok.")
if __name__=='__main__': main()
