import pandas as pd, numpy as np, yaml, os
from scripts._feat_build import read_raw, build_features
def triple_barrier(close: pd.Series, tp=0.12, sl=0.06, t=10):
    labels = []
    for i in range(len(close)):
        p0 = close.iloc[i]
        up = p0*(1+tp); dn = p0*(1-sl); j_end = min(i+t, len(close)-1)
        hit=None
        for j in range(i+1, j_end+1):
            px = close.iloc[j]
            if px>=up: hit=1; break
            if px<=dn: hit=0; break
        if hit is None:
            hit = int(close.iloc[j_end] > p0)
        labels.append(hit)
    return pd.Series(labels, index=close.index, name="tb_label")
def main():
    cfg = yaml.safe_load(open("config/alpha_hardening.yaml","r",encoding="utf-8"))
    if not cfg["meta_labeling"]["enable"]: 
        print("Meta-Labeling disabled"); return
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    out=[]
    for t in wl:
        df = read_raw(t)
        if df.empty: continue
        close = df['close'].astype(float).reset_index(drop=True)
        y = triple_barrier(close, cfg["meta_labeling"]["tp_barrier_pct"], cfg["meta_labeling"]["sl_barrier_pct"], cfg["meta_labeling"]["time_barrier_days"])
        out.append(pd.DataFrame({"ticker":t, "idx":np.arange(len(y)), "tb_label":y}))
    if out:
        pd.concat(out).to_csv("data/curated/meta_labels.csv", index=False)
        print("Meta-Labels -> data/curated/meta_labels.csv")
if __name__=='__main__': main()
