import pandas as pd, numpy as np, os
from pathlib import Path

def benjamini_hochberg(pvals, alpha=0.1):
    p = np.array(pvals); n = len(p); idx = np.argsort(p); pv = p[idx]
    thresh = (np.arange(1,n+1)/n) * alpha
    ok = pv <= thresh
    k = np.where(ok)[0].max()+1 if ok.any() else 0
    cutoff = pv[k-1] if k>0 else None
    return cutoff, idx[:k] if k>0 else []

def main():
    # expects per-parameter sweep results with p-values (e.g., bootstrap p of outperformance)
    path = "data/validation/sweep_stats.csv"
    if not os.path.exists(path):
        print("sweep_stats.csv nicht gefunden."); return
    df = pd.read_csv(path)
    cutoff, keep_idx = benjamini_hochberg(df["p_value"].values, alpha=0.1)
    df["keep"] = False
    if keep_idx != []:
        df.loc[keep_idx, "keep"] = True
    Path("data/validation").mkdir(parents=True, exist_ok=True)
    df.to_csv("data/validation/sweep_stats_fdr.csv", index=False)
    print("FDR angewendet. cutoff=", cutoff)
if __name__=='__main__': main()
