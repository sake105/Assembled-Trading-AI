import pandas as pd, numpy as np, yaml, os
from scripts._feat_build import read_raw
def main():
    cfg = yaml.safe_load(open("config/risk.yaml","r",encoding="utf-8"))
    if not cfg["vol_target"]["enable"]:
        print("Vol-target disabled"); return
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    rows=[]
    for t in wl:
        df = read_raw(t)
        if df.empty or len(df)<cfg["vol_target"]["lookback_days"]+1: continue
        ret = df['close'].astype(float).pct_change().dropna()
        vol = ret.rolling(cfg["vol_target"]["lookback_days"]).std().iloc[-1]*np.sqrt(252)
        target = cfg["vol_target"]["target_vol_pa"]
        scale = float(target/ vol) if vol>0 else 1.0
        rows.append((t, float(vol), float(scale)))
    pd.DataFrame(rows, columns=["ticker","vol_pa","scale"]).to_csv("data/curated/vol_target.csv", index=False)
    print("Vol-target scales -> data/curated/vol_target.csv")
if __name__=='__main__': main()
