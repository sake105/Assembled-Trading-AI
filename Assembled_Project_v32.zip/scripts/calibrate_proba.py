import pandas as pd, numpy as np, yaml, os, joblib
from pathlib import Path
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from scripts._feat_build import read_raw, build_features
def main():
    cfg = yaml.safe_load(open("config/alpha_hardening.yaml","r",encoding="utf-8"))
    if not cfg["calibration"]["enable"]: 
        print("Calibration disabled"); return
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    Path("data/models").mkdir(parents=True, exist_ok=True)
    for t in wl:
        # Need ML proba history => re-score full history if available (simplified: use last N points)
        # Here we fallback to simple isotonic on rolling window using close->binary label
        # In production you align model proba per day with triple-barrier labels.
        try:
            # Load model if exists, otherwise skip
            mp = Path(f"data/models/{t}_gb.joblib")
            if not mp.exists(): 
                continue
            pack = joblib.load(mp); model = pack["model"]; cols = pack["columns"]
            df = read_raw(t); feat = build_features(df, {})
            X = feat.select_dtypes(include=['float64','int64']).fillna(0.0)
            for c in list(X.columns):
                if c not in cols: X = X.drop(columns=[c])
            for c in cols:
                if c not in X.columns: X[c]=0.0
            X = X[cols]
            rawp = model.predict_proba(X)[:,1]
            # crude label proxy: 5d forward return > 0 (for calibration)
            y = (feat['close'].astype(float).pct_change(5).shift(-5) > 0).astype(int).fillna(0).values
            y = y[:len(rawp)]
            rawp = rawp[:len(y)]
            method = cfg["calibration"]["method"]
            if method=="isotonic":
                ir = IsotonicRegression(out_of_bounds='clip'); ir.fit(rawp, y)
                joblib.dump(ir, f"data/models/{t}_cal_isotonic.joblib")
            else:
                lr = LogisticRegression(max_iter=1000); lr.fit(rawp.reshape(-1,1), y)
                joblib.dump(lr, f"data/models/{t}_cal_platt.joblib")
        except Exception as ex:
            print(f"[cal] {t} skipped: {ex}")
    print("Calibration artifacts saved (where possible).")
if __name__=='__main__': main()
