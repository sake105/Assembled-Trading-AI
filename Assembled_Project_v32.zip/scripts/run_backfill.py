import os, pandas as pd
def main():
    os.makedirs("data/raw_history", exist_ok=True)
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    for t in wl:
        p = f"data/raw_history/{t}.csv"
        if not os.path.exists(p):
            idx = pd.date_range(end=pd.Timestamp.today(), periods=300, freq='B')
            price = 100
            import numpy as np
            ret = np.random.normal(0,0.01,len(idx))
            price = 100*np.cumprod(1+ret)
            df = pd.DataFrame({'date':idx, 'open':price, 'high':price*1.01, 'low':price*0.99, 'close':price, 'volume':100000})
            df.to_csv(p, index=False)
    print("Backfill fertig (synthetisch/offline).")
if __name__=='__main__': main()
