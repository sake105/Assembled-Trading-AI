import pandas as pd, numpy as np, yaml, os
from scripts._feat_build import read_raw, build_features
from src.signals.core import rule_score
from src.signals.blend import blend_scores
from src.validate.trade_engine import simulate_trades

def purged_kfold_indices(n, k=5, embargo=10):
    fold_size = n // k
    idx = []
    for i in range(k):
        start = i*fold_size
        end = (i+1)*fold_size if i<k-1 else n
        test = np.arange(start, end)
        train = np.setdiff1d(np.arange(n), np.arange(max(0,start-embargo), min(n,end+embargo)))
        idx.append((train, test))
    return idx

def run_ticker(t, cfg):
    df = read_raw(t)
    if df.empty: return pd.DataFrame()
    feat = build_features(df, cfg)
    score = blend_scores(rule_score(feat), t, cfg)
    results=[]
    idxs = purged_kfold_indices(len(feat), k=5, embargo=10)
    for fold,(tr,te) in enumerate(idxs,1):
        sub = feat.iloc[te].copy()
        sc  = score.iloc[te]
        trdf = simulate_trades(sub, sc, t,
                               cfg["backtest"]["entry"], cfg["backtest"]["exit"],
                               cfg["backtest"]["tp_pct"], cfg["backtest"]["sl_pct"],
                               cfg["portfolio"]["start_capital_eur"], cfg["portfolio"]["position_fraction"],
                               cfg["fees"]["trade_republic_per_order_eur"], cfg["slippage"]["roundtrip_bps"],
                               cfg["liquidity_filter"]["min_price_eur"], cfg["liquidity_filter"]["min_median_volume"],
                               cfg["portfolio"]["dynamic_sizing"], cfg["portfolio"]["kelly_scale"])
        if trdf.empty: continue
        eq=(1+trdf['net_ret']).cumprod()
        dd=float(min(0.0,(eq/eq.cummax()-1.0).min()))
        results.append((t, fold, float((trdf['hit']=='TP').mean()), float(eq.iloc[-1]-1.0), dd, len(trdf)))
    return pd.DataFrame(results, columns=["ticker","fold","HitRate","Ret","MaxDD","Ntrades"])

def main():
    cfg = yaml.safe_load(open("config/config.yaml","r",encoding="utf-8"))
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    out=[]
    for t in wl:
        r = run_ticker(t, cfg)
        if not r.empty: out.append(r)
    if out:
        pd.concat(out).to_csv("data/validation/wf_purged.csv", index=False); print("wf_purged.csv fertig.")
    else:
        print("keine WF-Ergebnisse.")
if __name__=='__main__': main()
