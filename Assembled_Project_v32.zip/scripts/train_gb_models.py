import os, yaml, joblib, pandas as pd
from pathlib import Path
from scripts._feat_build import read_raw, build_features
from sklearn.ensemble import GradientBoostingClassifier
def build_training_set(feat: pd.DataFrame, lookahead=5):
    c = feat['close'].astype(float)
    y = (c.pct_change(lookahead).shift(-lookahead) > 0).astype(int)
    X = feat.select_dtypes(include=['float64','int64']).fillna(0.0)
    drop = [col for col in X.columns if X[col].std()==0.0]
    X = X.drop(columns=drop, errors='ignore')
    X = X.iloc[:-lookahead]; y = y.iloc[:-lookahead]
    return X, y
def main():
    cfg = yaml.safe_load(open("config/model.yaml","r",encoding="utf-8"))
    if not cfg.get("ml",{}).get("enable", True): 
        print("ML disabled."); return
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    Path("data/models").mkdir(parents=True, exist_ok=True)
    for t in wl:
        df = read_raw(t)
        if df.empty: continue
        feat = build_features(df, {})
        X, y = build_training_set(feat, cfg["ml"]["lookahead_days"])
        if len(X) < int(cfg["ml"]["train_min_points"]): 
            print(f"[ML] skip {t}: too few points ({len(X)})")
            continue
        model = GradientBoostingClassifier(random_state=cfg["ml"]["random_state"])
        model.fit(X, y)
        joblib.dump({"model":model, "columns":list(X.columns)}, f"data/models/{t}_gb.joblib")
        print(f"[ML] trained {t}, n={len(X)}")
if __name__=='__main__': main()
