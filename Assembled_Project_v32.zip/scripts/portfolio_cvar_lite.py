import pandas as pd, numpy as np, yaml, os
from pathlib import Path
def main():
    cfg = yaml.safe_load(open("config/alpha_hardening.yaml","r",encoding="utf-8"))
    valp = "data/validation/validation_report.csv"
    if not os.path.exists(valp): 
        print("validation_report.csv fehlt"); return
    val = pd.read_csv(valp)
    # CVaR-lite proxy: penalize tail losses using MaxDD and lower quantile of daily returns if available.
    # We approximate using MaxDD as tail proxy and favor higher CAGR/HitRate.
    s = (val["CAGR"].clip(lower=0) * (val["HitRate"].clip(lower=0.6)) * (1.0 + val["AvgNet"])).fillna(0.0)
    tail_pen = 1.0 + (-val["MaxDD"]).clip(lower=0.0)
    w = (s / tail_pen).fillna(0.0)
    # enforce limits
    w = w / w.sum() if w.sum()>0 else w
    w = np.minimum(w, cfg["portfolio"]["max_weight"])
    # ensure min names
    order = np.argsort(-w)
    if (w>0).sum() < int(cfg["portfolio"]["min_names"]):
        topk = order[:int(cfg["portfolio"]["min_names"])]
        w[:] = 0.0
        w[topk] = 1.0/len(topk)
    out = val[["ticker"]].copy(); out["weight"] = w
    Path("data/curated").mkdir(parents=True, exist_ok=True)
    out.to_csv("data/curated/portfolio_weights_cvar.csv", index=False)
    print("CVaR-lite Portfolio -> data/curated/portfolio_weights_cvar.csv")
if __name__=='__main__': main()
