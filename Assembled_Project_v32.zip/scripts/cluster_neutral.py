import pandas as pd, os
from pathlib import Path

def main():
    # Optional: expects fundamentals.csv with columns [ticker, sector]
    p = Path("data/curated/fundamentals.csv")
    if not p.exists():
        print("fundamentals.csv fehlt -> Cluster-Neutralität übersprungen.")
        return
    f = pd.read_csv(p)
    # Allow max 1 top-idea per sector in Top-K
    f.to_csv("data/curated/cluster_map.csv", index=False)
    print("Cluster map gespeichert (sector).")
if __name__=='__main__': main()
