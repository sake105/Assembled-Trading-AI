import pandas as pd, yaml, os
def main():
    # read current regime
    rp = "data/curated/regime_market.csv"
    if not os.path.exists(rp):
        print("Kein Regime-File."); return
    reg = pd.read_csv(rp).tail(1)
    state = "sideways"
    if not reg.empty:
        if reg['bull'].iloc[-1]>0: state="bull"
        elif reg['bear'].iloc[-1]>0: state="bear"
    cfg = yaml.safe_load(open("config/regime_weights.yaml","r",encoding="utf-8"))
    adj = cfg["regimes"].get(state, {"entry_bonus":0,"ml_weight_add":0})
    pd.DataFrame([{"state":state, **adj}]).to_csv("data/curated/regime_adjustments.csv", index=False)
    print("Regime adjustments -> data/curated/regime_adjustments.csv")
if __name__=='__main__': main()
