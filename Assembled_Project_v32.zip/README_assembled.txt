Assembled_Project_v32 – bereits gepatchte Projektstruktur.
1) .venv erzeugen und Requirements installieren
2) python scripts/orchestrate.py
3) streamlit run app/streamlit_app.py
