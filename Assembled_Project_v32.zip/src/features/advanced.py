import pandas as pd, numpy as np

def ema(series, span):
    return series.ewm(span=span, adjust=False).mean()

def supertrend(df, period=10, multiplier=3.0):
    h,l,c = df['high'].astype(float), df['low'].astype(float), df['close'].astype(float)
    tr = (h - l).abs().combine((h - c.shift(1)).abs(), max).combine((l - c.shift(1)).abs(), max)
    atr = tr.rolling(period).mean()
    hl2 = (h + l) / 2.0
    upperband = hl2 + multiplier*atr
    lowerband = hl2 - multiplier*atr
    st = pd.Series(index=df.index, dtype=float)
    dir_up = True
    for i in range(len(df)):
        if i == 0:
            st.iat[i] = upperband.iat[i]
            continue
        prev = st.iat[i-1]
        if c.iat[i] > prev:
            st.iat[i] = lowerband.iat[i]
            dir_up = True
        else:
            st.iat[i] = upperband.iat[i]
            dir_up = False
    return pd.DataFrame({'supertrend': st, 'st_dir_up': (c>st).astype(int)})

def donchian(df, n=20):
    h,l = df['high'].astype(float), df['low'].astype(float)
    up = h.rolling(n).max()
    dn = l.rolling(n).min()
    mid = (up+dn)/2.0
    return pd.DataFrame({'donch_up':up,'donch_dn':dn,'donch_mid':mid})

def cci(df, n=20):
    h,l,c = df['high'].astype(float), df['low'].astype(float), df['close'].astype(float)
    tp = (h+l+c)/3.0
    sma = tp.rolling(n).mean()
    md = (tp - sma).abs().rolling(n).mean()
    cci = (tp - sma) / (0.015*(md+1e-12))
    return pd.Series(cci, name='cci')

def trix(df, n=15):
    c = df['close'].astype(float)
    e1 = ema(c, n); e2 = ema(e1, n); e3 = ema(e2, n)
    trix = e3.pct_change()*100
    return pd.Series(trix, name='trix')

def pct_b(df, n=20, k=2.0):
    c = df['close'].astype(float)
    mavg = c.rolling(n).mean(); mstd = c.rolling(n).std()
    upper = mavg + k*mstd; lower = mavg - k*mstd
    pb = (c - lower) / (upper - lower + 1e-12)
    width = (upper - lower)/(mavg+1e-12)
    return pd.DataFrame({'bb_pctB':pb, 'bb_width':width})

def keltner_width(df, n=20, k=1.5):
    c = df['close'].astype(float); h,l = df['high'].astype(float), df['low'].astype(float)
    mavg = c.rolling(n).mean()
    tr = (h - l).abs().combine((h - c.shift(1)).abs(), max).combine((l - c.shift(1)).abs(), max)
    rangema = tr.rolling(n).mean()
    up = mavg + k*rangema; dn = mavg - k*rangema
    return pd.DataFrame({'kc_width': (up-dn)/(mavg+1e-12)})

def ema_cross(df, fast=12, slow=26):
    c = df['close'].astype(float)
    ef = ema(c, fast); es = ema(c, slow)
    cross = (ef > es).astype(int)
    return pd.DataFrame({'ema_fast':ef,'ema_slow':es,'ema_bull':cross})

def atrn(df, n=14):
    h,l,c = df['high'].astype(float), df['low'].astype(float), df['close'].astype(float)
    tr = (h - l).abs().combine((h - c.shift(1)).abs(), max).combine((l - c.shift(1)).abs(), max)
    return tr.rolling(n).mean().rename('atr')

def advanced_feature_block(df):
    out = pd.DataFrame(index=df.index)
    out = pd.concat([out,
                     supertrend(df),
                     donchian(df),
                     cci(df),
                     trix(df),
                     pct_b(df),
                     keltner_width(df),
                     ema_cross(df),
                     atrn(df)], axis=1)
    return out
