import pandas as pd, numpy as np, os, yaml
def blend_scores(rule_score_series, ticker, cfg):
    # Base
    s = rule_score_series.clip(0,100).copy()
    # News boosts
    boost_map = {}; sent_map = {}
    if os.path.exists("data/curated/news_scores.csv"):
        d = pd.read_csv("data/curated/news_scores.csv"); boost_map = {str(r["ticker"]): float(r["news_score"]) for _,r in d.iterrows()}
    if os.path.exists("data/curated/news_sentiment.csv"):
        d = pd.read_csv("data/curated/news_sentiment.csv"); sent_map = {str(r["ticker"]): float(r["sentiment"]) for _,r in d.iterrows()}
    cap = cfg.get("sentiment",{}).get("cap_points",8.0)
    sent_points = max(-cap, min(cap, float(sent_map.get(ticker,0.0))*cap))
    s = (s + float(boost_map.get(ticker,0.0))*10.0 + sent_points).clip(0,100)
    # Regime (legacy)
    try:
        reg = pd.read_csv("data/curated/regime_market.csv")
        reg["date"]=pd.to_datetime(reg["date"]).dt.tz_localize(None)
        idx = pd.to_datetime(s.index).tz_localize(None)
        reg = reg.set_index("date").reindex(idx, method="ffill")
        s = s + reg["bull"]*3 - reg["bear"]*3
    except Exception:
        pass
    # ML proba blend
    try:
        mcfg = yaml.safe_load(open("config/model.yaml","r",encoding="utf-8"))
        if mcfg.get("ml",{}).get("enable", True) and os.path.exists("data/curated/ml_scores.csv"):
            ml = pd.read_csv("data/curated/ml_scores.csv")
            p = float(ml[ml['ticker']==ticker]['proba'].tail(1).values[0]) if (ml['ticker']==ticker).any() else None
            if p is not None:
                center = float(mcfg["ml"].get("proba_center",0.55))
                weight = float(mcfg["ml"].get("proba_weight",12.0))
                # regime mixer add
                if os.path.exists("data/curated/regime_adjustments.csv"):
                    ra = pd.read_csv("data/curated/regime_adjustments.csv").tail(1)
                    weight += float(ra['ml_weight_add'].iloc[-1])
                bonus = max(0.0, (p - center) / max(1e-3, (1.0-center))) * weight
                s = (s + bonus).clip(0,100)
    except Exception:
        pass
    # entry bonus/malus
    try:
        if os.path.exists("data/curated/regime_adjustments.csv"):
            ra = pd.read_csv("data/curated/regime_adjustments.csv").tail(1)
            s = s + float(ra['entry_bonus'].iloc[-1])
    except Exception:
        pass
    return s.clip(0,100)
