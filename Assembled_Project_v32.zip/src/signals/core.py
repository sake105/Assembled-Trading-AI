import pandas as pd, numpy as np
def rule_score(feat: pd.DataFrame) -> pd.Series:
    s = pd.Series(0.0, index=feat.index)
    s += (feat['sma20']>feat['sma50']).astype(float)*40
    s += (feat['rsi14'].between(45,65)).astype(float)*30
    s += (feat['ret1']>0).astype(float)*30
    return (100*s/100).clip(0,100)
