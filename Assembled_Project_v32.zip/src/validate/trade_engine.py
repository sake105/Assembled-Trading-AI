import pandas as pd, numpy as np
def simulate_trades(feat, score, ticker, entry, exit, tp, sl, capital, frac, fee, slip_bps, min_price, min_vol, dyn, kelly):
    # naive backtest: enter when score crosses up entry; exit on exit or TP/SL
    px = feat['close'].astype(float).reset_index(drop=True)
    sc = score.reset_index(drop=True)
    pos=False; p0=0; equity=[1.0]; hits=[]
    for i in range(1, len(px)):
        if not pos and sc.iloc[i-1]<entry and sc.iloc[i]>=entry:
            pos=True; p0=px.iloc[i]
        elif pos:
            ret=(px.iloc[i]/p0)-1.0
            if ret>=tp: pos=False; hits.append('TP')
            elif ret<=-sl: pos=False; hits.append('SL')
            elif sc.iloc[i]<=exit: pos=False; hits.append('EXIT')
        equity.append(equity[-1]*(1.0 + (ret if pos else 0.0)))
    return pd.DataFrame({'net_ret':pd.Series(equity).pct_change().fillna(0),'hit':hits+[None]*(len(equity)-len(hits))})
