Sprint01 – Projektinitialisierung
