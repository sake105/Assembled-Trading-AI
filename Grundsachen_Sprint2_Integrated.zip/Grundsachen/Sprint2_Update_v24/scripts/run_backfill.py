# --- auto-load .env (project root) ---
try:
    import os
    from pathlib import Path
    from dotenv import load_dotenv
    _THIS = Path(__file__).resolve()
    _ROOT = _THIS.parents[2]  # .../Grundsachen
    env_path = _ROOT / ".env"
    if env_path.exists():
        load_dotenv(env_path)
except Exception:
    pass
# -------------------------------------

"""Backfill EOD (20y) via yfinance"""
import os, pandas as pd
from pathlib import Path
import yfinance as yf
def save_by_year(df: pd.DataFrame, out_dir: Path):
    df = df.dropna().copy()
    df["date"] = pd.to_datetime(df.index).tz_localize(None)
    df = df.rename(columns=str.lower)[["open","high","low","close","adj close","volume"]]
    df = df.rename(columns={"adj close":"adj_close"}).reset_index(drop=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    for y, chunk in df.groupby(df["date"].dt.year):
        chunk.to_parquet(out_dir/f"{y}.parquet", index=False)
def run(watchlist_path="config/watchlist.txt"):
    wl = [l.strip() for l in open(watchlist_path,"r",encoding="utf-8").read().splitlines() if l.strip()]
    for t in wl:
        try:
            print(f"[EOD] {t} …")
            data = yf.download(t, period="20y", interval="1d", auto_adjust=False, progress=False)
            if data is None or data.empty:
                print(f"[WARN] Keine Daten: {t}"); continue
            save_by_year(data, Path("data/raw")/t)
        except Exception as ex:
            print(f"[ERR] {t}: {ex}")
if __name__=="__main__": run()
