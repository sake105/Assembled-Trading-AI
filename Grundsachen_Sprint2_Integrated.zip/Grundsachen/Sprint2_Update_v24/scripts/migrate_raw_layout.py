from __future__ import annotations
from pathlib import Path
import pandas as pd

# Convert flat files data/raw/*.csv|*.parquet -> data/raw/<TICKER>/<YYYY>.parquet
ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / "data" / "raw"
BACKUP = RAW / "_flat_backup"

def ensure_date(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "date" not in df.columns:
        df = df.reset_index(drop=False)
        for c in ("date","Date","Datetime","timestamp","time","index"):
            if c in df.columns:
                df = df.rename(columns={c:"date"}); break
        if "date" not in df.columns:
            for c in df.columns:
                s = pd.to_datetime(df[c], errors="coerce")
                if s.notna().sum() >= max(1, int(len(s)*0.5)):
                    df = df.rename(columns={c:"date"}); break
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    try: df["date"] = df["date"].dt.tz_localize(None)
    except Exception: pass
    df = df.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
    return df

def normalize_cols(df: pd.DataFrame) -> pd.DataFrame:
    d = {c:c.lower() for c in df.columns}
    df = df.rename(columns=d)
    if "adj close" in df.columns and "adj_close" not in df.columns:
        df = df.rename(columns={"adj close":"adj_close"})
    return df

def to_yearly_parquet(df: pd.DataFrame, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    keep = [c for c in ("date","open","high","low","close","adj_close","volume") if c in df.columns]
    if "date" not in keep: keep = ["date"] + [c for c in keep if c!="date"]
    if not keep: keep = list(df.columns)
    df = df[keep]
    for y, chunk in df.groupby(df["date"].dt.year):
        chunk.to_parquet(out_dir / f"{y}.parquet", index=False)

def migrate():
    RAW.mkdir(parents=True, exist_ok=True)
    BACKUP.mkdir(parents=True, exist_ok=True)
    flat = [p for p in RAW.glob("*.*") if p.is_file() and p.suffix.lower() in (".csv",".parquet")]
    for f in flat:
        ticker = f.stem.upper()
        tgt = RAW / ticker
        try:
            df = pd.read_parquet(f) if f.suffix.lower()==".parquet" else pd.read_csv(f)
        except Exception:
            print(f"[SKIP] {f.name}: unreadable file"); continue
        df = ensure_date(df)
        if df.empty:
            print(f"[SKIP] {f.name}: no date values"); continue
        df = normalize_cols(df)
        to_yearly_parquet(df, tgt)
        (BACKUP / f.name).write_bytes(f.read_bytes())
        f.unlink()
        print(f"[OK] {ticker}: migrated -> {tgt}")
    print("[DONE] Migration completed.")

if __name__ == "__main__":
    migrate()
