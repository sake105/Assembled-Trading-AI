# --- auto-load .env (project root) ---
try:
    import os
    from pathlib import Path
    from dotenv import load_dotenv
    _THIS = Path(__file__).resolve()
    _ROOT = _THIS.parents[2]  # .../Grundsachen
    env_path = _ROOT / ".env"
    if env_path.exists():
        load_dotenv(env_path)
except Exception:
    pass
# -------------------------------------

from src.news.aggregator import run as run_agg
from src.news.sentiment import compute_sentiment
if __name__=="__main__":
    run_agg(); compute_sentiment()
