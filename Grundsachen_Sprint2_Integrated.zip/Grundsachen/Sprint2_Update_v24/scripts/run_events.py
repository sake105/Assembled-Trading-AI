# --- auto-load .env (project root) ---
try:
    import os
    from pathlib import Path
    from dotenv import load_dotenv
    _THIS = Path(__file__).resolve()
    _ROOT = _THIS.parents[2]  # .../Grundsachen
    env_path = _ROOT / ".env"
    if env_path.exists():
        load_dotenv(env_path)
except Exception:
    pass
# -------------------------------------

from src.events.earnings_av import run_earnings
if __name__=="__main__": run_earnings()
