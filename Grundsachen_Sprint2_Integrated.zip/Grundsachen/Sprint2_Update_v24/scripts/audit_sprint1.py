# --- auto-load .env (project root) ---
try:
    import os
    from pathlib import Path
    from dotenv import load_dotenv
    _THIS = Path(__file__).resolve()
    _ROOT = _THIS.parents[2]  # .../Grundsachen
    env_path = _ROOT / ".env"
    if env_path.exists():
        load_dotenv(env_path)
except Exception:
    pass
# -------------------------------------

\"\"\"Audit Sprint‑1 completeness & environment sanity.\"\"\"
import os, json
expected = [
  'requirements.txt',
  'config/config.yaml',
  'config/watchlist.txt',
  'config/news/news_whitelist.yaml',
  'config/news/news_blacklist.yaml',
  'scripts/run_backfill.py',
  'scripts/run_news.py',
  'scripts/run_screener.py',
  'src/features/trend.py',
  'src/features/squeeze.py',
  'src/features/volatility.py',
  'src/features/regime.py',
  'src/features/momentum.py',
  'src/signals/core.py',
  'src/backtest/engine.py',
  'src/news/minimal.py',
  'src/news/aggregator.py',
  'src/news/sentiment.py',
  'src/events/earnings_av.py',
  'scripts/run_events.py',
  'src/ui/app.py',
  'oneclick/run_all.ps1'
]
missing = [p for p in expected if not os.path.exists(p)]
report = {
  "cwd": os.getcwd(),
  "missing": missing,
  "ok_count": len(expected)-len(missing),
  "expected_count": len(expected)
}
print(json.dumps(report, indent=2, ensure_ascii=False))
if missing:
  raise SystemExit(1)
