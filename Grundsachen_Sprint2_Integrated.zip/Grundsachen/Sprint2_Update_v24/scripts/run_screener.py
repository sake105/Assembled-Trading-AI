# --- auto-load .env (project root) ---
try:
    import os
    from pathlib import Path
    from dotenv import load_dotenv
    _THIS = Path(__file__).resolve()
    _ROOT = _THIS.parents[2]  # .../Grundsachen
    env_path = _ROOT / ".env"
    if env_path.exists():
        load_dotenv(env_path)
except Exception:
    pass
# -------------------------------------

import os, glob, pandas as pd, numpy as np, yaml
from pathlib import Path
from src.features.trend import trend_features
from src.features.squeeze import squeeze_features
from src.features.volatility import rs_vol, yz_vol
from src.features.regime import regime_labels
from src.features.momentum import rsi, macd, adx
from src.signals.core import rule_score, apply_hysteresis
from src.backtest.engine import run_backtest
from src.scoring.enhanced import blend_scores
def read_cfg():
    if not os.path.exists("config/config.yaml"): return {}
    return yaml.safe_load(open("config/config.yaml","r",encoding="utf-8")) or {}
def read_raw(ticker):
    p = Path("data/raw")/ticker
    files = sorted(glob.glob(str(p/"*.parquet")))
    return pd.DataFrame() if not files else pd.concat([pd.read_parquet(f) for f in files]).sort_values("date").reset_index(drop=True)
def build_features(df, cfg):
    tf = trend_features(df); sq = squeeze_features(df)
    dfv = df.copy(); dfv["rs_vol"]=rs_vol(df); dfv["yz_vol"]=yz_vol(df)
    reg = regime_labels(df)
    if cfg.get("ta_extras",{}).get("enable", True):
        close = df["close"].astype(float)
        r = rsi(close, cfg["ta_extras"].get("rsi_period",14))
        m_line,m_sig,m_hist = macd(close, cfg["ta_extras"].get("macd_fast",12), cfg["ta_extras"].get("macd_slow",26), cfg["ta_extras"].get("macd_signal",9))
        plus_di, minus_di, adx_val = adx(df, cfg["ta_extras"].get("adx_period",14))
        extras = pd.DataFrame({"rsi": r, "macd": m_line, "macd_sig": m_sig, "macd_hist": m_hist,
                               "+DI": plus_di, "-DI": minus_di, "ADX": adx_val})
    else:
        extras = pd.DataFrame(index=df.index)
    return pd.concat([df, tf, sq, dfv[["rs_vol","yz_vol"]], reg, extras], axis=1)
def load_news_boost():
    p2 = "data/curated/news_scores.csv"
    if not os.path.exists(p2): return {}
    d = pd.read_csv(p2)
    return {str(r["ticker"]): float(r["news_score"])*10.0 for _,r in d.iterrows()}
def load_sentiment():
    p = "data/curated/news_sentiment.csv"
    if not os.path.exists(p): return {}
    d = pd.read_csv(p)
    return {str(r["ticker"]): float(r["sentiment"]) for _,r in d.iterrows()}
def load_earnings_dates(ticker):
    p = Path("data/curated/events")/f"earnings_{ticker}.parquet"
    return pd.read_parquet(p) if p.exists() else pd.DataFrame()
def earnings_gate_dates(earn_df, pre_days=2, post_days=1):
    gates=set()
    for _,r in earn_df.iterrows():
        d = r.get("reportedDate") or r.get("fiscalDateEnding")
        if pd.isna(d): continue
        d = pd.to_datetime(d).normalize()
        gates.update(pd.date_range(d-pd.Timedelta(days=pre_days), d+pd.Timedelta(days=post_days), freq="D"))
    return gates
def main():
    cfg = read_cfg()
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    news_boost = load_news_boost(); sent_map = load_sentiment()
    ev = cfg.get("events",{}).get("earnings",{}); gate_enable = ev.get("enable", True)
    pre_days, post_days = ev.get("pre_days_block",2), ev.get("post_days_block",1)
    results=[]; Path("data/features").mkdir(parents=True, exist_ok=True)
    for t in wl:
        df = read_raw(t)
        if df.empty: 
            print(f"[SKIP] {t} – keine Daten"); continue
        feat = build_features(df, cfg)
        base = rule_score(feat)
        boost = float(news_boost.get(t,0.0)); sent=float(sent_map.get(t,0.0))
        score = blend_scores(base, boost, sent, sent_cap_points=cfg.get("sentiment",{}).get("cap_points",10))
        if gate_enable:
            earn_df = load_earnings_dates(t)
            gates = earnings_gate_dates(earn_df, pre_days, post_days) if not earn_df.empty else set()
            idx_dates = pd.to_datetime(feat["date"]).dt.normalize()
            score = score.where(~idx_dates.isin(gates), other=np.minimum(score,54))
        sig = apply_hysteresis(score, entry=cfg.get("backtest",{}).get("entry",70), exit=cfg.get("backtest",{}).get("exit",55))
        rep = run_backtest(df, sig, cost_bps=cfg.get("backtest",{}).get("cost_bps",0.0))
        results.append((t, rep["CAGR"], rep["Sharpe"], rep["PF"], boost, sent))
        feat.to_parquet(Path("data/features")/f"{t}_features.parquet", index=False)
    out = pd.DataFrame(results, columns=["ticker","CAGR","Sharpe","PF","news_boost","sentiment"]).sort_values(["CAGR","Sharpe"], ascending=False)
    Path("data/curated").mkdir(parents=True, exist_ok=True)
    out.to_csv("data/curated/toplist.csv", index=False)
    print(out.head(30).to_string(index=False))
if __name__=="__main__": main()
