import pandas as pd, numpy as np
def run_backtest(df: pd.DataFrame, pos: pd.Series, cost_bps=0.0):
    p = df["close"].astype(float)
    ret = p.pct_change().fillna(0.0)
    pos = pos.reindex(df.index).fillna(0).astype(int)
    trades = pos.diff().fillna(0).abs()
    tc = trades*(cost_bps/10000.0)
    strat_ret = ret*pos - tc
    eq = (1.0+strat_ret).cumprod()
    if len(eq)<=1: return {"CAGR":0.0,"Sharpe":0.0,"PF":0.0}
    years = len(eq)/252.0
    cagr = (eq.iat[-1])**(1/years)-1.0 if years>0 else (eq.iat[-1]-1.0)
    vol = strat_ret.std()*(252**0.5)
    sharpe = (strat_ret.mean()*252)/(vol+1e-12)
    gains = strat_ret[strat_ret>0].sum(); losses = -strat_ret[strat_ret<0].sum()
    pf = (gains/(losses+1e-12)) if losses>0 else float("inf")
    return {"CAGR":float(cagr),"Sharpe":float(sharpe),"PF":float(pf)}
