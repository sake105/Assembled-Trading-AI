from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
def dedupe_texts(texts, thresh=0.9):
    if not texts: return []
    try:
        tf = TfidfVectorizer(stop_words="english", min_df=1).fit_transform(texts)
        sim = cosine_similarity(tf)
        keep, seen = [], set()
        for i in range(len(texts)):
            if i in seen: continue
            keep.append(texts[i])
            for j in range(i+1,len(texts)):
                if sim[i,j]>=thresh: seen.add(j)
        return keep
    except Exception:
        return list(dict.fromkeys(texts))
