import os, pandas as pd
from pathlib import Path
try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    _VADER_OK = True
except Exception:
    _VADER_OK = False
def compute_sentiment(news_parquet_dir="data/curated/news", out_csv="data/curated/news_sentiment.csv", hours=72):
    Path("data/curated").mkdir(parents=True, exist_ok=True)
    files = sorted([p for p in Path(news_parquet_dir).glob("news_*.parquet")])
    if not files: return None
    df = pd.concat([pd.read_parquet(p) for p in files]).dropna(subset=["text"])
    if "published" in df.columns:
        df = df[df["published"] >= (pd.Timestamp.utcnow() - pd.Timedelta(hours=hours))]
    if df.empty: return None
    if _VADER_OK:
        an = SentimentIntensityAnalyzer()
        df["sentiment"] = df["text"].astype(str).apply(lambda t: an.polarity_scores(t)["compound"])  # noqa
    else:
        df["sentiment"] = 0.0
    agg = df.groupby("tickers")["sentiment"].mean().reset_index().rename(columns={"tickers":"ticker"})
    agg.to_csv(out_csv, index=False)
    return agg
