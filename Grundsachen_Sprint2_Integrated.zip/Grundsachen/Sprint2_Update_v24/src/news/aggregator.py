import os, re, time, math, datetime as dt
from pathlib import Path
import yaml, feedparser, pandas as pd
from bs4 import BeautifulSoup
from src.news.minimal import dedupe_texts
def load_yaml(path):
    if not os.path.exists(path): return {}
    with open(path,"r",encoding="utf-8") as f: 
        import yaml; return yaml.safe_load(f) or {}
def in_sections(url, allow, deny, deny_global):
    path = re.sub(r"^https?://[^/]+","", url or "").lower()
    if any(d in path for d in (deny or [])): return False
    if any(d in path for d in (deny_global or [])): return False
    return True if not allow else any(a in path for a in allow)
def parse_time(entry):
    for k in ("published_parsed","updated_parsed"):
        t = entry.get(k)
        if t: 
            import datetime as dt, time
            return dt.datetime.fromtimestamp(time.mktime(t), tz=dt.timezone.utc).replace(tzinfo=None)
    return dt.datetime.utcnow()
def clean_text(html_or_text):
    if not html_or_text: return ""
    try:  text = BeautifulSoup(html_or_text, "lxml").get_text(" ")
    except: text = str(html_or_text)
    return re.sub(r"\s+"," ", text).strip()
def attention_score(n_articles_weighted): return float(math.tanh(0.3 * n_articles_weighted))
def run(news_whitelist="config/news/news_whitelist.yaml", news_blacklist="config/news/news_blacklist.yaml", watchlist_path="config/watchlist.txt"):
    srcs = (load_yaml(news_whitelist) or {}).get("sources", [])
    deny_global = (load_yaml(news_blacklist) or {}).get("deny_paths", [])
    if not srcs: print("[WARN] keine Quellen"); return
    wl = [l.strip() for l in open(watchlist_path,"r",encoding="utf-8").read().splitlines() if l.strip()] if os.path.exists(watchlist_path) else []
    rows = []
    for s in srcs:
        for feed in (s.get("rss") or []):
            try:
                d = feedparser.parse(feed)
                for e in d.entries:
                    url = e.get("link","");
                    pub = parse_time(e)
                    if not in_sections(url, s.get("sections_allow"), s.get("sections_deny"), deny_global): continue
                    if s.get("max_age_hours") and (dt.datetime.utcnow()-pub).total_seconds() > s["max_age_hours"]*3600: continue
                    title = clean_text(e.get("title",""))
                    body  = clean_text(e.get("summary","") or e.get("description",""))
                    if len(body) < int(s.get("min_len",0)): continue
                    rows.append({"source": s.get("domain"), "trust": float(s.get("trust",0.8)), "url": url,
                                 "published": pub, "title": title, "text": body})
            except Exception as ex:
                print(f"[WARN] Feed fail {feed}: {ex}")
    if not rows: print("[INFO] keine Artikel"); return
    df = pd.DataFrame(rows)
    kept = dedupe_texts(df["title"].fillna("").tolist(), 0.9)
    df = df[df["title"].isin(kept)].copy()
    def map_to_tickers(text):
        t_low = (text or "").lower(); hits=[]
        import re
        for t in wl:
            if re.search(rf"\b{re.escape(t)}\b", t_low, re.I): hits.append(t)
        return list(set(hits))
    df["tickers"] = df["text"].apply(map_to_tickers)
    df = df.explode("tickers").dropna(subset=["tickers"])
    Path("data/curated/news").mkdir(parents=True, exist_ok=True)
    today = dt.datetime.utcnow().strftime("%Y%m%d")
    df.to_parquet(f"data/curated/news/news_{today}.parquet", index=False)
    attn = df.groupby(["tickers"]).apply(lambda g: (g["trust"]).sum()).reset_index()
    attn.columns = ["ticker","weighted_count"]
    attn["news_score"] = attn["weighted_count"].apply(attention_score).clip(-1,1)
    attn[["ticker","news_score"]].to_csv("data/curated/news_scores.csv", index=False)
    print(attn.sort_values("news_score", ascending=False).head(20).to_string(index=False))
