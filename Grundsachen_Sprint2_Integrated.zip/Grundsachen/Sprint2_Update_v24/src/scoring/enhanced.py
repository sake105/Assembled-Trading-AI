import pandas as pd
def blend_scores(rule_score: pd.Series, news_boost_points: float, sent_score: float, sent_cap_points=10.0):
    sent_points = max(-sent_cap_points, min(sent_cap_points, sent_score * sent_cap_points))
    return (rule_score + news_boost_points + sent_points).clip(0,100)
