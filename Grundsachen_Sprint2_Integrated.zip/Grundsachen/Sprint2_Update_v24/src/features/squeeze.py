import pandas as pd, numpy as np
def squeeze_features(df: pd.DataFrame, bb_n=20, bb_k=2.0, kc_n=20, kc_k=1.5):
    high, low, close = df["high"].astype(float), df["low"].astype(float), df["close"].astype(float)
    mavg = close.rolling(bb_n).mean(); mstd = close.rolling(bb_n).std()
    bb_up = mavg + bb_k*mstd; bb_dn = mavg - bb_k*mstd
    tr = (high - low).abs().combine((high - close.shift(1)).abs(), max).combine((low - close.shift(1)).abs(), max)
    rangema = tr.rolling(kc_n).mean()
    kc_up = mavg + kc_k*rangema; kc_dn = mavg - kc_k*rangema
    squeeze_on = ((bb_up < kc_up) & (bb_dn > kc_dn)).astype(int)
    return pd.DataFrame({"bb_up":bb_up,"bb_dn":bb_dn,"kc_up":kc_up,"kc_dn":kc_dn,"squeeze_on":squeeze_on})
