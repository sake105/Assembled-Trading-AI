import os, requests, pandas as pd
from pathlib import Path
def fetch_earnings_alpha_vantage(ticker:str, key:str):
    url = "https://www.alphavantage.co/query"
    params = {"function":"EARNINGS", "symbol": ticker, "apikey": key}
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    js = r.json()
    q = js.get("quarterlyEarnings", []) or []
    if not q: return pd.DataFrame()
    df = pd.DataFrame(q)
    for c in ("fiscalDateEnding","reportedDate"):
        if c in df.columns: df[c] = pd.to_datetime(df[c], errors="coerce")
    keep = ["fiscalDateEnding","reportedDate","surprise","surprisePercentage"]
    for c in keep:
        if c not in df.columns: df[c] = None
    return df[keep].dropna(subset=["fiscalDateEnding"], how="all")
def run_earnings(watchlist_path="config/watchlist.txt", out_dir="data/curated/events"):
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    key = os.environ.get("ALPHAVANTAGE_KEY","");
    if not key:
        print("[INFO] ALPHAVANTAGE_KEY fehlt – Earnings werden übersprungen."); return
    wl = [l.strip() for l in open(watchlist_path,"r",encoding="utf-8") if l.strip()]
    for t in wl:
        try:
            df = fetch_earnings_alpha_vantage(t, key)
            if df is None or df.empty:
                print(f"[WARN] Keine Earnings-Daten: {t}"); continue
            df.to_parquet(f"{out_dir}/earnings_{t}.parquet", index=False)
            print(f"[OK] Earnings gespeichert: {t} ({len(df)})")
        except Exception as ex:
            print(f"[WARN] {t} Earnings Fehler: {ex}")
