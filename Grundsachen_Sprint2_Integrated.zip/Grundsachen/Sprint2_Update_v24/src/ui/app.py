import streamlit as st, pandas as pd, os, datetime as dt, glob
st.set_page_config(page_title="TradingSystem – Sprint 2 (Consolidated, FINAL)", layout="wide")
tab1, tab2 = st.tabs(["Overview", "News & Events"])
with tab1:
    st.title("TradingSystem – Sprint 2 (Consolidated, FINAL)")
    st.caption(f"Build: {dt.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    st.subheader("Top-Liste (CAGR/Sharpe/PF/News-Boost/Sentiment)")
    if os.path.exists("data/curated/toplist.csv"):
        st.dataframe(pd.read_csv("data/curated/toplist.csv").head(30), use_container_width=True)
    else:
        st.info("Noch keine Top-Liste gefunden. Bitte Backfill & Screener ausführen.")
with tab2:
    st.subheader("News-Scores & Sentiment (72h)")
    colA, colB = st.columns(2)
    with colA:
        if os.path.exists("data/curated/news_scores.csv"):
            st.write("**Attention / Velocity (gewichtete Häufigkeit)**")
            st.dataframe(pd.read_csv("data/curated/news_scores.csv").sort_values("news_score", ascending=False), use_container_width=True, height=420)
        else:
            st.info("Noch keine News-Scores.")
    with colB:
        if os.path.exists("data/curated/news_sentiment.csv"):
            st.write("**Durchschnittliches Sentiment (VADER)**")
            st.dataframe(pd.read_csv("data/curated/news_sentiment.csv").sort_values("sentiment", ascending=False), use_container_width=True, height=420)
        else:
            st.info("Noch kein Sentiment berechnet.")
    st.subheader("Earnings (Events)")
    files = glob.glob("data/curated/events/earnings_*.parquet")
    if files:
        frames=[]
        for f in files:
            t = os.path.basename(f).replace("earnings_","\").replace(".parquet","")
            df = pd.read_parquet(f); df["ticker"]=t; frames.append(df)
        st.dataframe(pd.concat(frames).sort_values("reportedDate", na_position="last").tail(100), use_container_width=True)
    else:
        st.info("Noch keine Earnings-Events vorhanden.")
