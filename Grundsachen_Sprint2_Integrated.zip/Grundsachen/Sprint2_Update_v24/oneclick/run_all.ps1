$ErrorActionPreference = "Stop"
if (-not (Test-Path ".\.venv")) { python -m venv .venv }
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python scripts\audit_sprint1.py
python scripts\run_backfill.py
python scripts\run_events.py
python scripts\run_news.py
python scripts\run_screener.py
try { streamlit run src\ui\app.py } catch { Write-Host "UI start skipped." }
