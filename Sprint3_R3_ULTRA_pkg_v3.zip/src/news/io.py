import os, pandas as pd
def load_news_boost_csv(path="data/curated/news_scores.csv"):
    if not os.path.exists(path): return {}
    d = pd.read_csv(path)
    return {str(r["ticker"]): float(r["news_score"]) for _,r in d.iterrows()}
def load_sentiment_csv(path="data/curated/news_sentiment.csv"):
    if not os.path.exists(path): return {}
    d = pd.read_csv(path)
    return {str(r["ticker"]): float(r["sentiment"]) for _,r in d.iterrows()}
