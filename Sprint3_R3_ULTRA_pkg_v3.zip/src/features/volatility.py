import pandas as pd, numpy as np
def rs_vol(df: pd.DataFrame, window=20):
    ret = df["close"].astype(float).pct_change()
    return ret.rolling(window).std()*(252**0.5)
def yz_vol(df: pd.DataFrame, window=20):
    return rs_vol(df, window)
