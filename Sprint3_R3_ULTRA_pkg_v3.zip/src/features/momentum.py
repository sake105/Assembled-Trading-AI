import pandas as pd, numpy as np
def rsi(series: pd.Series, period=14):
    d = series.diff()
    up = (d.clip(lower=0)).ewm(alpha=1/period, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs = up/(dn+1e-12)
    return 100-(100/(1+rs))
def macd(series: pd.Series, fast=12, slow=26, signal=9):
    ef = series.ewm(span=fast, adjust=False).mean()
    es = series.ewm(span=slow, adjust=False).mean()
    line = ef-es; sig = line.ewm(span=signal, adjust=False).mean()
    return line, sig, (line-sig)
def adx(df: pd.DataFrame, period=14):
    h,l,c = df["high"].astype(float), df["low"].astype(float), df["close"].astype(float)
    plus_dm = (h - h.shift(1)).clip(lower=0)
    minus_dm = (l.shift(1) - l).clip(lower=0)
    tr = (h - l).abs().combine((h - c.shift(1)).abs(), max).combine((l - c.shift(1)).abs(), max)
    atr = tr.rolling(period).mean()
    plus_di = 100*(plus_dm.rolling(period).mean()/(atr+1e-12))
    minus_di= 100*(minus_dm.rolling(period).mean()/(atr+1e-12))
    dx = 100*((plus_di-minus_di).abs()/((plus_di+minus_di)+1e-12))
    return plus_di, minus_di, dx.rolling(period).mean()
