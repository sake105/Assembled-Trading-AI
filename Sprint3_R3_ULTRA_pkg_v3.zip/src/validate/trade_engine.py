import pandas as pd, numpy as np
from ..etl.adjusters import portfolio_ccy_view, adjust_ohlc
def simulate_trades(df: pd.DataFrame, score: pd.Series, ticker: str,
                    entry=70, exit=55, tp=0.18, sl=0.08,
                    start_capital=10000.0, position_fraction=1.0,
                    fee_per_order_eur=1.0, roundtrip_slippage_bps=15,
                    min_price_eur=7.0, min_median_vol=300000):
    df = adjust_ohlc(df)
    df, ccy = portfolio_ccy_view(df, ticker)
    med_vol = float(df["volume"].median()) if "volume" in df.columns else 0.0
    if med_vol < min_median_vol:
        return pd.DataFrame(columns=["ticker","entry_date","entry_price_eur","exit_date","exit_price_eur",
                                     "gross_ret","net_ret","hit","mfe","mae","shares","ccy"])
    close_eur = df.get("close_eur", df["close"]).astype(float).values
    highs_eur = df.get("high_eur", df["high"]).astype(float).values
    lows_eur  = df.get("low_eur", df["low"]).astype(float).values
    opens_eur = df.get("open_eur", df["open"]).astype(float).values
    dates = pd.to_datetime(df["date"] if "date" in df.columns else df.index)
    pos = pd.Series(0, index=score.index, dtype=int)
    in_pos=False
    for i, val in enumerate(score):
        if not in_pos and val>=entry: in_pos=True
        elif in_pos and val<=exit:    in_pos=False
        pos.iat[i] = 1 if in_pos else 0
    slipp = roundtrip_slippage_bps/10000.0
    trades=[]; i=0
    while i < len(df)-1:
        if pos.iloc[i]==0 or (i>0 and pos.iloc[i-1]==1):
            i+=1; continue
        entry_idx = i
        exec_idx = min(i+1, len(df)-1)
        if opens_eur[exec_idx] < min_price_eur:
            i+=1; continue
        entry_price = float(opens_eur[exec_idx])
        capital = start_capital * position_fraction
        shares = max(1, int(capital // entry_price))
        fee_frac = (2.0 * fee_per_order_eur) / (shares * entry_price)
        tp_level = entry_price*(1.0+tp); sl_level = entry_price*(1.0-sl)
        j = exec_idx; hit = None; mfe = -np.inf; mae = np.inf
        while j < len(df):
            h = float(highs_eur[j]); l = float(lows_eur[j])
            mfe = max(mfe, (h/entry_price)-1.0); mae = min(mae, (l/entry_price)-1.0)
            if l <= sl_level: exit_price = sl_level*(1.0 - slipp/2); hit='SL'; break
            if h >= tp_level: exit_price = tp_level*(1.0 - slipp/2); hit='TP'; break
            if j+1 < len(df) and pos.iloc[j+1]==0:
                exit_price = float(opens_eur[j+1])*(1.0 - slipp/2); hit='SIG'; j+=1; break
            j+=1
        if j>=len(df): exit_price = float(close_eur[-1])*(1.0 - slipp/2); hit='END'
        gross = (exit_price - entry_price)/entry_price
        net = gross - fee_frac - slipp
        trades.append({"ticker": ticker,"entry_date": dates[min(exec_idx, len(dates)-1)],
                       "entry_price_eur": entry_price,"exit_date": dates[min(j, len(dates)-1)],
                       "exit_price_eur": exit_price,"gross_ret": float(gross),"net_ret": float(net),
                       "hit": hit,"mfe": float(mfe),"mae": float(mae),"shares": int(shares),"ccy": ccy})
        i = j+1
    return pd.DataFrame(trades)
