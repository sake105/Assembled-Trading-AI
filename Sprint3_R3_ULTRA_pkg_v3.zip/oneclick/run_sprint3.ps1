$ErrorActionPreference = "Stop"
if (-not (Test-Path ".\.venv")) { python -m venv .venv }
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python scripts\run_backfill.py
python scripts\run_sprint3_validation.py --min_trades 35 --max_dd -0.35
Write-Host "Sprint 3 R3 finished. See data\validation, data\curated\thresholds.csv and config\thresholds_runtime.yaml"
