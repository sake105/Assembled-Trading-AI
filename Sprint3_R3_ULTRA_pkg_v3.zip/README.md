Sprint 3 R3 – ULTRA (Mentor-Defaults)
Start:
  PowerShell (als Prozess): Set-ExecutionPolicy Bypass
  Dann: .\oneclick\run_sprint3.ps1
