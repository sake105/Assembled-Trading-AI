import os, glob, argparse, json, time
from pathlib import Path
import pandas as pd, numpy as np, yaml
from src.features.trend import trend_features
from src.features.squeeze import squeeze_features
from src.features.volatility import rs_vol, yz_vol
from src.features.regime import regime_labels
from src.features.momentum import rsi, macd, adx
from src.signals.core import rule_score
from src.news.io import load_news_boost_csv, load_sentiment_csv
from src.validate.trade_engine import simulate_trades
from src.validate.sweep import sweep_thresholds, pick_best
def read_cfg():
    if not os.path.exists("config/config.yaml"): return {}
    return yaml.safe_load(open("config/config.yaml","r",encoding="utf-8")) or {}
def read_raw(ticker):
    p = Path("data/raw")/ticker
    files = sorted(glob.glob(str(p/"*.parquet")))
    return pd.DataFrame() if not files else pd.concat([pd.read_parquet(f) for f in files]).sort_values("date").reset_index(drop=True)
def build_features(df, cfg):
    tf = trend_features(df); sq = squeeze_features(df)
    dfv = df.copy(); dfv["rs_vol"]=rs_vol(df); dfv["yz_vol"]=yz_vol(df)
    reg = regime_labels(df)
    if cfg.get("ta_extras",{}).get("enable", True):
        close = df["close"].astype(float)
        r = rsi(close, cfg["ta_extras"].get("rsi_period",14))
        m_line,m_sig,m_hist = macd(close, cfg["ta_extras"].get("macd_fast",12), cfg["ta_extras"].get("macd_slow",26), cfg["ta_extras"].get("macd_signal",9))
        plus_di, minus_di, adx_val = adx(df, cfg["ta_extras"].get("adx_period",14))
        extras = pd.DataFrame({"rsi": r, "macd": m_line, "macd_sig": m_sig, "macd_hist": m_hist,
                               "+DI": plus_di, "-DI": minus_di, "ADX": adx_val})
    else:
        extras = pd.DataFrame(index=df.index)
    feat = pd.concat([df, tf, sq, dfv[["rs_vol","yz_vol"]], reg, extras], axis=1)
    return feat
def blend_scores(rule_score_series, ticker, cfg):
    boost_map = load_news_boost_csv()
    sent_map  = load_sentiment_csv()
    boost = float(boost_map.get(ticker,0.0))*10.0
    sent  = float(sent_map.get(ticker,0.0))
    cap   = cfg.get("sentiment",{}).get("cap_points",8.0)
    sent_points = max(-cap, min(cap, sent*cap))
    return (rule_score_series + boost + sent_points).clip(0,100)
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tickers", type=str, default="", help="Comma-separated tickers (default: all in watchlist)")
    ap.add_argument("--min_trades", type=int, default=35)
    ap.add_argument("--max_dd", type=float, default=-0.35)
    args = ap.parse_args()
    cfg = read_cfg()
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    if args.tickers:
        keep = set([t.strip() for t in args.tickers.split(",") if t.strip()])
        wl = [t for t in wl if t in keep]
    out_dir = Path("data/validation"); out_dir.mkdir(parents=True, exist_ok=True)
    Path("data/curated").mkdir(parents=True, exist_ok=True)
    Path("logs").mkdir(parents=True, exist_ok=True)
    rows=[]; thresholds=[]
    for t in wl:
        df = read_raw(t)
        if df.empty:
            rows.append((t,0.0,0.0,0.0,0.0,0)); continue
        feat = build_features(df, cfg)
        base = rule_score(feat)
        score = blend_scores(base, t, cfg)
        entry, exit = cfg.get("backtest",{}).get("entry",72), cfg.get("backtest",{}).get("exit",57)
        tp, sl = cfg.get("backtest",{}).get("tp_pct",0.16), cfg.get("backtest",{}).get("sl_pct",0.08)
        cap = cfg.get("portfolio",{}).get("start_capital_eur",10000.0)
        frac= cfg.get("portfolio",{}).get("position_fraction",1.0)
        fee = cfg.get("fees",{}).get("trade_republic_per_order_eur",1.0)
        slip= cfg.get("slippage",{}).get("roundtrip_bps",15)
        minp= cfg.get("liquidity_filter",{}).get("min_price_eur",7.0)
        minv= cfg.get("liquidity_filter",{}).get("min_median_volume",300000)
        tr = simulate_trades(feat, score, t, entry, exit, tp, sl, cap, frac, fee, slip, minp, minv)
        tr.to_csv(out_dir/f"trade_log_{t}.csv", index=False)
        if tr.empty:
            rows.append((t,0.0,0.0,0.0,0.0,0))
            continue
        eq = (1.0+tr['net_ret']).cumprod()
        years = max(1e-6, len(tr)/252.0)
        cagr = (eq.iloc[-1])**(1/years)-1.0 if len(eq)>0 else 0.0
        hr = float((tr['hit']=='TP').mean())
        avg = tr['net_ret'].mean()
        dd = float(min(0.0, (eq/eq.cummax()-1.0).min()))
        rows.append((t,cagr,hr,avg,dd,len(tr)))
        sw = sweep_thresholds(feat, score, t, start_capital=cap, position_fraction=frac, fee_per_order_eur=fee,
                              roundtrip_slippage_bps=slip, min_price_eur=minp, min_median_vol=minv)
        sw.to_csv(out_dir/f"threshold_sweep_{t}.csv", index=False)
        pick = pick_best(sw, args.min_trades, args.max_dd)
        if pick is not None and not pick.empty:
            r = pick.iloc[0]
            thresholds.append((t, int(r["entry"]), int(r["exit"]), float(r["tp"]), float(r["sl"]), float(r["CAGR"]), float(r["HitRate"]), int(r["Ntrades"])))
    pd.DataFrame(rows, columns=["ticker","CAGR","HitRate","AvgNet","MaxDD","Ntrades"]).to_csv(out_dir/"validation_report.csv", index=False)
    pd.DataFrame(thresholds, columns=["ticker","entry","exit","tp","sl","CAGR","HitRate","Ntrades"]).to_csv("data/curated/thresholds.csv", index=False)
    import yaml
    runtime = {"thresholds": {r[0]: {"entry": int(r[1]), "exit": int(r[2]), "tp": float(r[3]), "sl": float(r[4])} for r in thresholds}}
    with open("config/thresholds_runtime.yaml","w",encoding="utf-8") as f:
        yaml.safe_dump(runtime, f)
    print("Done Sprint 3 R3: see data/validation/, data/curated/thresholds.csv and config/thresholds_runtime.yaml")
if __name__=="__main__":
    main()
