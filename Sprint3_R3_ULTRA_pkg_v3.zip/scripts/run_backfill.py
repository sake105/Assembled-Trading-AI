import os, pandas as pd
from pathlib import Path
import yfinance as yf
from tqdm import tqdm
def save_by_year(df: pd.DataFrame, out_dir: Path):
    df = df.dropna().copy()
    df["date"] = pd.to_datetime(df.index).tz_localize(None)
    df = df.rename(columns=str.lower)[["open","high","low","close","adj close","volume"]]
    df = df.rename(columns={"adj close":"adj_close"}).reset_index(drop=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    for y, chunk in df.groupby(df["date"].dt.year):
        chunk.to_parquet(out_dir/f"{y}.parquet", index=False)
def run(watchlist_path="config/watchlist.txt"):
    wl = [l.strip() for l in open(watchlist_path,"r",encoding="utf-8").read().splitlines() if l.strip()]
    for t in tqdm(wl, desc="Backfill"):
        try:
            data = yf.download(t, period="20y", interval="1d", auto_adjust=False, progress=False)
            if data is None or data.empty:
                print(f"[WARN] Keine Daten: {t}"); continue
            save_by_year(data, Path("data/raw")/t)
        except Exception as ex:
            print(f"[ERR] {t}: {ex}")
if __name__=="__main__": run()
