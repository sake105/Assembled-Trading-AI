
$ErrorActionPreference="Stop"
$patchDir = Join-Path (Get-Location) "patches"
$ordered = @(
    "Sprint01_CoreInit.zip",
    "Sprint02_CoreRefresh.zip","Sprint03_CoreRefresh.zip","Sprint04_CoreRefresh.zip","Sprint05_CoreRefresh.zip",
    "Sprint06_CoreRefresh.zip","Sprint07_CoreRefresh.zip","Sprint08_CoreRefresh.zip","Sprint09_CoreRefresh.zip","Sprint10_CoreRefresh.zip",
    "Sprint11_CoreRefresh.zip","Sprint12_CoreRefresh.zip","Sprint13_CoreRefresh.zip","Sprint14_CoreRefresh.zip","Sprint15_CoreRefresh.zip",
    "Sprint16_CoreRefresh.zip","Sprint17_CoreRefresh.zip","Sprint18_CoreRefresh.zip","Sprint19_CoreRefresh.zip","Sprint20_CoreRefresh.zip",
    "Sprint21_CoreRefresh.zip","Sprint22_CoreRefresh.zip",
    "Sprint23_AllFixes_Pro.zip",
    "Sprint24_AlphaHardening.zip",
    "Sprint25_PurgedWF_FDR.zip",
    "Sprint26_VolTarget_AdaptiveStops.zip",
    "Sprint27_EarningsIQ.zip",
    "Sprint30_Liquidity_Cluster.zip",
    "Sprint31_PortfolioVol_RegimeMixer.zip",
    "Sprint29_Explainability_SHAP.zip",
    "Sprint28_AutoTradeBridge_SAFE.zip"
)
foreach ($zipName in $ordered) {
    $zipPath = Join-Path $patchDir $zipName
    if (!(Test-Path $zipPath)) { Write-Warning "Fehlt: $zipName"; continue }
    Write-Host "==> Wende $zipName an..." -ForegroundColor Cyan
    $tmp = Join-Path $env:TEMP ([System.IO.Path]::GetFileNameWithoutExtension($zipName))
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    New-Item -ItemType Directory -Path $tmp | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $tmp)
    $overlay = Join-Path $tmp "overlay"
    if (Test-Path $overlay) { Copy-Item "$overlay\*" -Destination (Get-Location) -Recurse -Force }
    $apply = Join-Path $tmp "apply_patch.ps1"
    if (Test-Path $apply) { & $apply }
}
Write-Host "ALLE SPRINTS angewendet." -ForegroundColor Green
