
$ErrorActionPreference="Stop"
if (!(Test-Path ".\.venv")) { py -3 -m venv .venv }
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
if (Test-Path ".\requirements.txt") { pip install -r requirements.txt } else { pip install pandas numpy scikit-learn joblib pyyaml streamlit }
