
Master_Full_AllSprints_v32 (offline-fähig)

- patches/Sprint01_CoreInit.zip  -> Voller Basis-Stack (Config, Backfill, Features, Signals, Backtest, UI)
- patches/Sprint02..22_CoreRefresh.zip -> Funktions-Refresh (identische Basismodule wiederholen, falls einzeln angewendet)
- patches/Sprint23..31 -> Fortgeschrittene Patches (Alpha-Hardening, ML, Risk, Regime, Liquidity, Explainability, SAFE Autotrade)

Ablauf (empfohlen):
  1) .\setup_master.ps1
  2) .\apply_all_sprints.ps1
  3) .\.venv\Scripts\Activate.ps1
  4) python scripts\orchestrate.py
  5) Streamlit starten

Hinweis: Backfill erzeugt offline synthetische Daten, wenn keine Historien vorhanden sind (data/raw_history).
