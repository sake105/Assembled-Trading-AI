"""
Backtest mit Kosten
"""
import numpy as np, pandas as pd

def run_backtest(df: pd.DataFrame, signals: pd.Series, fee_eur=1.0, slippage_bps=7):
    px = df["close"].astype(float)
    pos = signals.fillna(0).astype(int)
    ret = px.pct_change().fillna(0)
    strat = (pos.shift(1)*ret)
    chg = pos.diff().fillna(0).abs()
    slip = (slippage_bps/10000.0)
    strat -= chg*slip
    eq = (1+strat).cumprod()
    cagr = eq.iloc[-1]**(252/len(eq)) - 1 if len(eq)>0 else 0.0
    dd = (eq/eq.cummax()-1).min()
    vol = strat.std()*np.sqrt(252)
    sharpe = (strat.mean()*252)/(vol+1e-12)
    losses_sum = strat[strat<0].sum()
    pf = (strat[strat>0].sum() / abs(losses_sum+1e-12)) if losses_sum!=0 else 1.0
    return {"CAGR": float(cagr), "Sharpe": float(sharpe), "MaxDD": float(dd), "PF": float(pf)}
