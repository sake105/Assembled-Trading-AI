"""
Signals: Gating + Hysterese
"""
import pandas as pd, numpy as np

def rule_score(feat: pd.DataFrame):
    score = pd.Series(0.0, index=feat.index)
    score += 40 * feat["ema_cross"].fillna(0)
    score += 30 * (feat["squeeze_ratio"].diff() > 0).astype(int)
    score += 30 * (feat.get("regime").astype(str).str.contains("_low")).astype(int)
    return score.clip(0,100)

def apply_hysteresis(score: pd.Series, entry=70, exit=55):
    state = 0
    signals = []
    for v in score.fillna(0):
        if state==0 and v>=entry: state=1
        elif state==1 and v<exit: state=0
        signals.append(state)
    return pd.Series(signals, index=score.index, name="in_position")
