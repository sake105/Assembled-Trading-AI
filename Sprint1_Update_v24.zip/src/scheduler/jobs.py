"""
APScheduler – EOD Job
"""
from apscheduler.schedulers.background import BackgroundScheduler
import subprocess

def job_eod():
    subprocess.call("python scripts/run_screener.py", shell=True)

def start_scheduler():
    s = BackgroundScheduler()
    s.add_job(job_eod, "cron", hour=22, minute=0)
    s.start()
    return s
