"""
Streamlit UI – Sprint 1
"""
import streamlit as st, pandas as pd, os
st.set_page_config(page_title="TradingSystem – Sprint 1", layout="wide")
st.title("TradingSystem – Sprint 1")

st.write("Nach Backfill & Screener erscheinen hier Heatmap/Top‑Listen.")

toplist = "data/curated/toplist.csv"
if os.path.exists(toplist):
    df = pd.read_csv(toplist)
    st.subheader("Top‑Liste (CAGR/Sharpe/PF)")
    st.dataframe(df.head(20), use_container_width=True)
else:
    st.info("Noch keine Top‑Liste gefunden. Bitte Backfill & Screener ausführen.")
