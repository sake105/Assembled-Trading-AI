"""
Portfolio: Fee-Gate, ATR-Stops, Sizing
"""
import math

def fee_gate_ok(notional_eur: float, fee_gate: float=800.0) -> bool:
    return notional_eur >= fee_gate

def atr_stop(entry: float, atr_val: float, k_init=2.0, k_trail=3.0):
    sl = entry - k_init*atr_val
    trail = entry - k_trail*atr_val
    return sl, trail

def position_size(portfolio_value: float, risk_per_trade: float, atr_val: float, entry: float):
    risk_eur = portfolio_value*risk_per_trade
    if atr_val<=0: return 0, 0.0
    qty = max(0, math.floor(risk_eur/atr_val))
    return qty, qty*entry
