"""
Composite Score
"""
def composite(rule_score: float, news_score: float=0.0, ml_proba: float=0.0, w=(0.7,0.2,0.1)):
    return 100*(w[0]*rule_score/100 + w[1]*(news_score+1)/2 + w[2]*ml_proba)
