"""
Volatilität: Rogers–Satchell & Yang–Zhang
"""
import numpy as np, pandas as pd

def rs_vol(df: pd.DataFrame, n:int=20):
    o,h,l,c = df["open"], df["high"], df["low"], df["close"]
    rs = (np.log(h/o)*np.log(h/c) + np.log(l/o)*np.log(l/c))
    return (rs.rolling(n).mean().clip(lower=0).pow(0.5))*np.sqrt(252)

def yz_vol(df: pd.DataFrame, n:int=20):
    o,h,l,c = [df[k].astype(float) for k in ("open","high","low","close")]
    k = 0.34/(1.34 + (n+1)/(n-1))
    log_oc = np.log(c/o)
    log_oo = np.log(o/o.shift(1)).fillna(0)
    log_cc = np.log(c.shift(1)/c.shift(2)).fillna(0)
    sigma_o = (log_oo**2).rolling(n).mean()
    sigma_c = (log_cc**2).rolling(n).mean()
    sigma_rs = (np.log(h/o)*np.log(h/c) + np.log(l/o)*np.log(l/c)).rolling(n).mean()
    yz = sigma_o + k*sigma_c + (1-k)*sigma_rs
    return (yz.clip(lower=0).pow(0.5))*np.sqrt(252)
