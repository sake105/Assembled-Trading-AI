"""
Trend & Stabilität (EMA50/EMA200, R^2)
"""
import numpy as np, pandas as pd

def ema(s, n): return s.ewm(span=n, adjust=False).mean()

def trend_features(df: pd.DataFrame, win:int=100):
    close = df["close"].astype(float)
    ema50 = ema(close, 50); ema200 = ema(close, 200)
    ema_cross = (ema50 > ema200).astype(int)
    y = np.log(close.replace(0, np.nan)).ffill()
    x = np.arange(len(y))
    r2 = pd.Series(np.nan, index=df.index)
    for i in range(win, len(y)+1):
        yy = y.iloc[i-win:i]; xx = x[i-win:i]
        A = np.vstack([xx, np.ones_like(xx)]).T
        m, b = np.linalg.lstsq(A, yy, rcond=None)[0]
        yhat = m*xx + b
        ss_res = ((yy - yhat)**2).sum()
        ss_tot = ((yy - yy.mean())**2).sum()
        r2.iloc[i-1] = 1 - (ss_res/ss_tot if ss_tot>0 else 0)
    return pd.DataFrame({"ema50": ema50, "ema200": ema200, "ema_cross": ema_cross, "trend_r2": r2})
