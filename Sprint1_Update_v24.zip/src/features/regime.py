"""
Regime-Labels
"""
import pandas as pd, numpy as np

def regime_labels(df: pd.DataFrame):
    close = df["close"].astype(float)
    ema50 = close.ewm(span=50, adjust=False).mean()
    ema200 = close.ewm(span=200, adjust=False).mean()
    bull = (ema50 > ema200)
    ret = close.pct_change()
    vol = (ret.rolling(20).std()*np.sqrt(252))
    v_th = vol.rolling(252).median()
    highvol = vol > v_th
    label = []
    for b, hv in zip(bull, highvol):
        if pd.isna(b) or pd.isna(hv): label.append(None); continue
        t = "bull" if b else "bear"
        v = "high" if hv else "low"
        label.append(f"{t}_{v}")
    return pd.Series(label, index=df.index, name="regime")
