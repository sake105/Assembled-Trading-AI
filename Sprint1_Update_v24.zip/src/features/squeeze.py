"""
Squeeze+: Bollinger width vs ATR, Dauer
"""
import pandas as pd, numpy as np

def bbands(close: pd.Series, n=20, k=2):
    ma = close.rolling(n).mean()
    sd = close.rolling(n).std()
    upper = ma + k*sd
    lower = ma - k*sd
    width = (upper - lower)/ma
    return ma, upper, lower, width

def atr(df, n=14):
    prev = df["close"].shift(1)
    tr = (df["high"]-df["low"]).abs().combine((df["high"]-prev).abs(), max).combine((df["low"]-prev).abs(), max)
    return tr.rolling(n).mean()

def squeeze_features(df: pd.DataFrame):
    ma, upper, lower, width = bbands(df["close"])
    a = atr(df)
    squeeze = (width/a).rolling(5).mean()
    dur = (squeeze < squeeze.quantile(0.2)).astype(int)
    dur = dur.groupby((dur != dur.shift()).cumsum()).cumsum()
    return pd.DataFrame({"bb_width": width, "atr": a, "squeeze_ratio": squeeze, "squeeze_dur": dur})
