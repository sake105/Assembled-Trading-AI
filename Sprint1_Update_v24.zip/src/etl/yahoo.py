"""
ETL: Yahoo Finance (EOD) mit yfinance
"""
import os, datetime as dt
from pathlib import Path
import pandas as pd, numpy as np
import yfinance as yf

def fetch_eod_yahoo(ticker: str, years: int=20) -> pd.DataFrame:
    end = dt.date.today()
    start = end - dt.timedelta(days=int(years*365.25)+5)
    df = yf.download(ticker, start=start, end=end, auto_adjust=False, progress=False)
    if df is None or df.empty:
        return pd.DataFrame(columns=["date","open","high","low","close","adj_close","volume","currency"])
    df = df.rename(columns=str.lower).reset_index().rename(columns={"index":"date"})
    if "adj close" in df.columns: df = df.rename(columns={"adj close":"adj_close"})
    else: df["adj_close"] = df["close"]
    df["date"] = pd.to_datetime(df["date"]).dt.tz_localize(None)
    info = yf.Ticker(ticker).info or {}
    cur = info.get("currency","")
    df["currency"] = cur
    return df[["date","open","high","low","close","adj_close","volume","currency"]]

def fetch_corporate_actions(ticker: str) -> pd.DataFrame:
    tk = yf.Ticker(ticker)
    splits = tk.splits
    dividends = tk.dividends
    rows = []
    if splits is not None and len(splits)>0:
        for d,v in splits.items():
            rows.append({"date": pd.Timestamp(d), "type":"split", "value": float(v)})
    if dividends is not None and len(dividends)>0:
        for d,v in dividends.items():
            rows.append({"date": pd.Timestamp(d), "type":"dividend", "value": float(v)})
    if not rows:
        return pd.DataFrame(columns=["date","type","value"])
    ca = pd.DataFrame(rows).sort_values("date").reset_index(drop=True)
    return ca

def save_parquet(df: pd.DataFrame, ticker: str, root: str="data/raw"):
    p = Path(root)/ticker
    p.mkdir(parents=True, exist_ok=True)
    if df.empty: 
        return
    df["year"] = pd.to_datetime(df["date"]).dt.year
    for y,chunk in df.groupby("year"):
        out = p/f"{y}.parquet"
        chunk.drop(columns=["year"], errors="ignore").to_parquet(out, index=False)

def save_ca_log(ca: pd.DataFrame, ticker:str, root:str="data/curated/ca"):
    p = Path(root); p.mkdir(parents=True, exist_ok=True)
    out = p/f"{ticker}.parquet"
    (ca if not ca.empty else pd.DataFrame(columns=["date","type","value"])).to_parquet(out, index=False)
