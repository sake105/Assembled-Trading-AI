"""
ETL: Alpha Vantage (EOD) Fallback
"""
import requests, pandas as pd
from pathlib import Path

def fetch_eod_alpha_vantage(ticker:str, key:str) -> pd.DataFrame:
    url = "https://www.alphavantage.co/query"
    params = {"function":"TIME_SERIES_DAILY_ADJUSTED","symbol":ticker,"outputsize":"full","apikey":key}
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    js = r.json()
    key_ts = "Time Series (Daily)"
    if key_ts not in js: return pd.DataFrame()
    recs = []
    for d, vals in js[key_ts].items():
        recs.append({
            "date": pd.to_datetime(d),
            "open": float(vals["1. open"]),
            "high": float(vals["2. high"]),
            "low": float(vals["3. low"]),
            "close": float(vals["4. close"]),
            "adj_close": float(vals.get("5. adjusted close", vals["4. close"])),
            "volume": float(vals["6. volume"]),
            "currency": ""
        })
    df = pd.DataFrame(recs).sort_values("date").reset_index(drop=True)
    return df

def save_parquet(df: pd.DataFrame, ticker: str, root: str="data/raw"):
    Path(root,ticker).mkdir(parents=True, exist_ok=True)
    if df.empty: return
    df["year"] = pd.to_datetime(df["date"]).dt.year
    for y,chunk in df.groupby("year"):
        chunk.drop(columns=["year"], errors="ignore").to_parquet(Path(root,ticker,f"{y}.parquet"), index=False)
