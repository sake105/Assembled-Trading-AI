"""
ETL: Finnhub (EOD) Fallback
"""
import time, requests, pandas as pd
from pathlib import Path

def fetch_eod_finnhub(ticker:str, key:str, years:int=20) -> pd.DataFrame:
    end = int(time.time())
    start = end - int(years*365.25*24*3600)
    url = "https://finnhub.io/api/v1/stock/candle"
    params = {"symbol": ticker, "resolution":"D", "from": start, "to": end, "token": key}
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    js = r.json()
    if js.get("s") != "ok": return pd.DataFrame()
    df = pd.DataFrame({"date": pd.to_datetime(js["t"], unit="s"),
                       "open": js["o"], "high": js["h"], "low": js["l"], "close": js["c"], "volume": js["v"]})
    df["adj_close"] = df["close"]
    df["currency"] = ""
    return df.sort_values("date").reset_index(drop=True)

def save_parquet(df: pd.DataFrame, ticker: str, root: str="data/raw"):
    Path(root,ticker).mkdir(parents=True, exist_ok=True)
    if df.empty: return
    df["year"] = pd.to_datetime(df["date"]).dt.year
    for y,chunk in df.groupby("year"):
        chunk.drop(columns=["year"], errors="ignore").to_parquet(Path(root,ticker,f"{y}.parquet"), index=False)
