# CHANGELOG – Sprint 1 (P0)
Date: 2025-08-21 10:32 UTC

- ETL Yahoo (EOD, 20y) + Fallbacks (Alpha Vantage, Finnhub)
- Corporate Actions (Splits/Dividenden) Log
- Handelskalender (NYSE/XETRA/LSE) & Sommer/Winterzeit
- Volatilität: Rogers–Satchell & Yang–Zhang
- Trend-Stabilität (EMA50/200, R²)
- Volatility Squeeze+ (BB/ATR)
- Regime-Labels (bull/bear/sideways × high/low vol)
- Gating-Order & Hysterese (Entry≥70 / Exit<55)
- Fee‑Gate, ATR‑Stops, Chandelier, TP‑Leitern (Basis vorbereitet)
- Backtest mit Kosten (1 € Order + 7 bps Slippage) & Report
- Streamlit UI: Heatmap & Top‑Listen (Day/Week/Month)
- APScheduler EOD-Jobs
- QA Self‑Test (Ampel)
- News minimal: Whitelist & Dedupe (TF‑IDF)
