"""
QA Self‑Test (Ampel)
"""
import os, json

def self_test()->dict:
    checks = []
    for p in ["config/config.yaml","config/watchlist.txt","config/news/news_whitelist.yaml","config/news/news_blacklist.yaml"]:
        checks.append((p, os.path.exists(p)))
    ok = all(v for _,v in checks)
    return {"ok": ok, "checks": checks}
