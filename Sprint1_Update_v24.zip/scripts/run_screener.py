"""
Screener Runner – Features, Signale, Backtest‑Kurzreport
"""
import os, glob, pandas as pd
from pathlib import Path
from src.features.trend import trend_features
from src.features.squeeze import squeeze_features
from src.features.volatility import rs_vol, yz_vol
from src.features.regime import regime_labels
from src.signals.core import rule_score, apply_hysteresis
from src.backtest.engine import run_backtest

def read_raw(ticker):
    p = Path("data/raw")/ticker
    files = sorted(glob.glob(str(p/"*.parquet")))
    if not files: return pd.DataFrame()
    df = pd.concat([pd.read_parquet(f) for f in files]).sort_values("date").reset_index(drop=True)
    return df

def build_features(df):
    tf = trend_features(df)
    sq = squeeze_features(df)
    dfv = df.copy()
    dfv["rs_vol"] = rs_vol(df)
    dfv["yz_vol"] = yz_vol(df)
    reg = regime_labels(df)
    feat = pd.concat([df, tf, sq, dfv[["rs_vol","yz_vol"]], reg], axis=1)
    return feat

def main():
    wl = [l.strip() for l in open("config/watchlist.txt","r",encoding="utf-8") if l.strip()]
    results = []
    for t in wl:
        df = read_raw(t)
        if df.empty: 
            print(f"[SKIP] {t} – keine Daten")
            continue
        feat = build_features(df)
        score = rule_score(feat)
        sig = apply_hysteresis(score, entry=70, exit=55)
        rep = run_backtest(df, sig)
        results.append((t, rep["CAGR"], rep["Sharpe"], rep["PF"]))
        Path("data/features").mkdir(exist_ok=True, parents=True)
        feat.to_parquet(Path("data/features")/f"{t}_features.parquet", index=False)
    out = pd.DataFrame(results, columns=["ticker","CAGR","Sharpe","PF"]).sort_values(["CAGR","Sharpe"], ascending=False)
    Path("data/curated").mkdir(parents=True, exist_ok=True)
    out.to_csv("data/curated/toplist.csv", index=False)
    print(out.head(15).to_string(index=False))

if __name__=="__main__":
    main()
