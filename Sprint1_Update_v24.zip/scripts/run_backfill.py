"""
Backfill Runner – orchestriert Yahoo + Fallbacks
"""
import os, pandas as pd
from pathlib import Path
from src.etl.yahoo import fetch_eod_yahoo, save_parquet, fetch_corporate_actions, save_ca_log
from src.etl.alpha_vantage import fetch_eod_alpha_vantage
from src.etl.finnhub import fetch_eod_finnhub

def load_watchlist(path="config/watchlist.txt"):
    if not os.path.exists(path): return []
    with open(path,"r",encoding="utf-8") as f:
        return [l.strip() for l in f if l.strip()]

def main():
    wl = load_watchlist()
    av = os.environ.get("ALPHAVANTAGE_KEY","")
    fh = os.environ.get("FINNHUB_KEY","")
    for t in wl:
        df = fetch_eod_yahoo(t, years=20)
        if df.empty and av:
            df = fetch_eod_alpha_vantage(t, av)
        if df.empty and fh:
            df = fetch_eod_finnhub(t, fh, years=20)
        if df.empty:
            print(f"[WARN] Keine Daten für {t}")
            continue
        save_parquet(df, t, "data/raw")
        ca = fetch_corporate_actions(t)
        save_ca_log(ca, t, "data/curated/ca")
        print(f"[OK] {t} – {len(df)} Zeilen")

if __name__=="__main__":
    main()
