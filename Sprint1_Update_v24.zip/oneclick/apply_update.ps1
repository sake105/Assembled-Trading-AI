# Apply Sprint 1 Update (Windows)
$ErrorActionPreference = "Stop"
$root = Get-Location
$backupDir = Join-Path $root "backups"
if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir | Out-Null }
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$zip = Join-Path $backupDir ("backup_" + $ts + ".zip")
Add-Type -AssemblyName 'System.IO.Compression.FileSystem'
[System.IO.Compression.ZipFile]::CreateFromDirectory($root, $zip)

Copy-Item -Path (Join-Path $PSScriptRoot "..\src") -Destination (Join-Path $root "src") -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\tools") -Destination (Join-Path $root "tools") -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\scripts") -Destination (Join-Path $root "scripts") -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\docs") -Destination (Join-Path $root "docs") -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\requirements.txt") -Destination (Join-Path $root "requirements.txt") -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\version.manifest.json") -Destination (Join-Path $root "version.manifest.json") -Force

Write-Host "Update angewendet. Starte One-Click Runner..."
if (Test-Path ".\oneclick\run_all.ps1") {
  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
  .\oneclick\run_all.ps1
} else {
  Write-Host "One-Click Runner nicht gefunden. Bitte manuell ausführen."
}
