#!/usr/bin/env bash
set -euo pipefail
ROOT="$(pwd)"
mkdir -p backups
TS=$(date +"%Y%m%d_%H%M%S")
zip -r "backups/backup_${TS}.zip" . >/dev/null

UPD_DIR="$(cd "$(dirname "$0")"/.. && pwd)"
cp -R "${UPD_DIR}/src" "${ROOT}/" 
cp -R "${UPD_DIR}/tools" "${ROOT}/" 
cp -R "${UPD_DIR}/scripts" "${ROOT}/" 
cp -R "${UPD_DIR}/docs" "${ROOT}/" 
cp "${UPD_DIR}/requirements.txt" "${ROOT}/requirements.txt"
cp "${UPD_DIR}/version.manifest.json" "${ROOT}/version.manifest.json"

if [ -f "oneclick/run_all.sh" ]; then
  chmod +x oneclick/run_all.sh
  oneclick/run_all.sh
else
  echo "One-Click Runner nicht gefunden. Bitte manuell starten."
fi
