"""
News Aggregator – Whitelist + RSS + Filter + Dedupe + Scores
"""
import os, re, time, math, datetime as dt
from pathlib import Path
import yaml, feedparser, pandas as pd
from bs4 import BeautifulSoup
from src.news.minimal import dedupe_texts

def load_whitelist(path="config/news/news_whitelist.yaml"):
    with open(path,"r",encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    return cfg.get("sources", [])

def in_sections(url, allow, deny):
    try:
        path = re.sub(r"^https?://[^/]+","", url).lower()
    except Exception:
        return False
    if any(d in path for d in (deny or [])): return False
    if allow:
        return any(a in path for a in allow)
    return True

def max_age_ok(published, hours:int):
    try:
        return (dt.datetime.utcnow() - published).total_seconds() <= hours*3600
    except Exception:
        return True

def clean_text(html_or_text):
    if not html_or_text: return ""
    text = BeautifulSoup(html_or_text, "lxml").get_text(" ")
    return re.sub(r"\s+"," ", text).strip()

def parse_time(entry):
    for k in ("published_parsed","updated_parsed"):
        t = entry.get(k)
        if t:
            return dt.datetime.fromtimestamp(time.mktime(t), tz=dt.timezone.utc).replace(tzinfo=None)
    return dt.datetime.utcnow()

def fetch_source(src):
    rss_list = src.get("rss") or []
    rows = []
    for feed in rss_list:
        try:
            d = feedparser.parse(feed)
            for e in d.entries:
                url = e.get("link","")
                pub = parse_time(e)
                if not in_sections(url, src.get("sections_allow"), src.get("sections_deny")): 
                    continue
                if not max_age_ok(pub, int(src.get("max_age_hours",72))): 
                    continue
                title = clean_text(e.get("title",""))
                summary = clean_text(e.get("summary","") or e.get("description",""))
                body = clean_text(summary)
                if len(body) < int(src.get("min_len",0)): 
                    continue
                rows.append({
                    "source": src.get("domain"),
                    "trust": float(src.get("trust", 0.8)),
                    "url": url,
                    "published": pub,
                    "title": title,
                    "text": body
                })
        except Exception as ex:
            print(f"[WARN] Feed fail {feed}: {ex}")
            continue
    return rows

def map_to_tickers(text, tickers):
    hits = []
    t_low = text.lower()
    for t in tickers:
        if not t: continue
        t_u = t.upper()
        if re.search(rf"\\b{re.escape(t_u)}\\b", text) or re.search(rf"\\b{re.escape(t)}\\b", t_low):
            hits.append(t)
    return list(set(hits))

def attention_score(n_articles_weighted):
    return float(math.tanh(0.3 * n_articles_weighted))

def run(news_whitelist="config/news/news_whitelist.yaml", watchlist_path="config/watchlist.txt"):
    if not os.path.exists(news_whitelist):
        print("[WARN] whitelist fehlt")
        return
    sources = load_whitelist(news_whitelist)
    if not sources:
        print("[WARN] keine Quellen")
        return
    tickers = [l.strip() for l in open(watchlist_path,"r",encoding="utf-8").read().splitlines() if l.strip()] if os.path.exists(watchlist_path) else []
    rows = []
    for s in sources:
        rows += fetch_source(s)
    if not rows:
        print("[INFO] keine Artikel")
        return
    import pandas as pd
    df = pd.DataFrame(rows)
    kept = dedupe_texts(df["title"].fillna("").tolist(), thresh=0.9)
    df = df[df["title"].isin(kept)].copy()
    df["tickers"] = df["text"].apply(lambda x: map_to_tickers(x, tickers))
    df = df.explode("tickers").dropna(subset=["tickers"])
    Path("data/curated/news").mkdir(parents=True, exist_ok=True)
    today = dt.datetime.utcnow().strftime("%Y%m%d")
    df.to_parquet(f"data/curated/news/news_{today}.parquet", index=False)
    attn = df.groupby(["tickers"]).apply(lambda g: (g["trust"]).sum()).reset_index()
    attn.columns = ["ticker","weighted_count"]
    attn["news_score"] = attn["weighted_count"].apply(attention_score).clip(-1,1)
    attn[["ticker","news_score"]].to_csv("data/curated/news_scores.csv", index=False)
    print(attn.sort_values("news_score", ascending=False).head(20).to_string(index=False))

if __name__=="__main__":
    run()
