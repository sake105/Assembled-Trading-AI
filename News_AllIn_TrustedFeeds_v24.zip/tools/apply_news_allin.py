# Apply ALL‑IN trusted feeds: merges whitelist & source_overrides
import os, yaml

def load_yaml(path):
    if not os.path.exists(path): return None
    with open(path,"r",encoding="utf-8") as f:
        return yaml.safe_load(f)

def save_yaml(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path,"w",encoding="utf-8") as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)

def merge_whitelist(sample_path="config/news/news_whitelist.sample.yaml", target_path="config/news/news_whitelist.yaml"):
    sample = load_yaml(sample_path) or {"sources":[]}
    target = load_yaml(target_path) or {"sources":[]}
    td = {s.get("domain"): s for s in target.get("sources",[]) if isinstance(s, dict)}
    changed = False
    for s in sample.get("sources",[]):
        dom = s.get("domain")
        if not dom: continue
        if dom in td:
            tgt = td[dom]
            # merge additively: rss union, fill missing keys
            for k,v in s.items():
                if k=="rss":
                    tv = tgt.get("rss") or []
                    new = [x for x in (v or []) if x not in tv]
                    if new:
                        tgt["rss"] = tv + new
                        changed = True
                else:
                    if k not in tgt or not tgt[k]:
                        tgt[k] = v
                        changed = True
        else:
            target["sources"].append(s)
            changed = True
    if changed:
        save_yaml(target_path, target)
    return changed

def merge_config_overrides(path="config/config.yaml"):
    cfg = load_yaml(path) or {}
    ns = cfg.get("news_scoring", {})
    overrides = ns.get("source_overrides", {})
    wanted = {
      "cnbc.com": 1.15, "reuters.com": 1.20, "bloomberg.com": 1.15,
      "wsj.com": 1.10, "ft.com": 1.10, "marketwatch.com": 1.05,
      "investing.com": 1.00, "finance.yahoo.com": 1.00,
      "deraktionaer.de": 1.05, "handelsblatt.com": 1.12,
      "faz.net": 1.08, "manager-magazin.de": 1.05,
      "boerse.ard.de": 1.05, "boerse-online.de": 1.00,
      "morningstar.com": 1.08, "barrons.com": 1.12
    }
    if "news_scoring" not in cfg:
        cfg["news_scoring"] = {"base_weight": 1.0, "source_overrides": wanted}
    else:
        cfg["news_scoring"]["source_overrides"] = {**wanted, **overrides}
        if "base_weight" not in cfg["news_scoring"]:
            cfg["news_scoring"]["base_weight"] = 1.0
    save_yaml(path, cfg)
    return True

def main():
    w = merge_whitelist()
    merge_config_overrides()
    print("ALL‑IN trusted feeds applied.", "Whitelist updated" if w else "Whitelist unchanged")

if __name__=="__main__":
    main()
