# Apply ALL‑IN News Patch (Windows)
$ErrorActionPreference = "Stop"
$root = Get-Location

# Copy files
Copy-Item -Path (Join-Path $PSScriptRoot "..\config") -Destination (Join-Path $root "config") -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\src") -Destination (Join-Path $root "src") -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\scripts") -Destination (Join-Path $root "scripts") -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\tools") -Destination (Join-Path $root "tools") -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot "..\requirements.txt") -Destination (Join-Path $root "requirements.txt") -Force

# Ensure deps
if (Test-Path ".\oneclick\run_all.ps1") {
  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
  .\oneclick\run_all.ps1 -NoUI
} else {
  pip install -r requirements.txt
}

# Merge whitelist & overrides
python tools\apply_news_allin.py

# Fetch news -> recompute scores -> rerun screener
python scripts\run_news.py
python scripts\run_screener.py

# Optional: launch UI if available
if (Test-Path "src\ui\app.py") {
  try { streamlit run src\ui\app.py } catch { Write-Host "UI start skipped." }
}
