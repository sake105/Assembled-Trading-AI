#!/usr/bin/env bash
set -euo pipefail

cp -R "$(dirname "$0")/../config" "./"
cp -R "$(dirname "$0")/../src" "./"
cp -R "$(dirname "$0")/../scripts" "./"
cp -R "$(dirname "$0")/../tools" "./"
cp "$(dirname "$0")/../requirements.txt" "./requirements.txt"

# ensure deps
if [ -f "oneclick/run_all.sh" ]; then
  bash oneclick/run_all.sh --no-ui || true
else
  pip3 install -r requirements.txt
fi

python3 tools/apply_news_allin.py
python3 scripts/run_news.py
python3 scripts/run_screener.py

if [ -f "src/ui/app.py" ]; then
  streamlit run src/ui/app.py || true
fi
